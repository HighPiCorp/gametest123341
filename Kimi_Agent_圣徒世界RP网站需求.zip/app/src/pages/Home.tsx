import { useState } from 'react';
import { motion } from 'framer-motion';
import { 
  Users, 
  Copy, 
  Check, 
  Gamepad2, 
  Download, 
  Search, 
  Play,
  ArrowRight,
  TrendingUp,
  Gift,
  Shield,
  Clock,
  Newspaper
} from 'lucide-react';
import GlassCard from '../components/GlassCard';
import NeonButton from '../components/NeonButton';
import AnimatedCounter from '../components/AnimatedCounter';

const Home = () => {
  const [copied, setCopied] = useState(false);
  const [donateAmount, setDonateAmount] = useState('');

  const serverIP = 'play.saintsworld.ru';

  const handleCopyIP = () => {
    navigator.clipboard.writeText(serverIP);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const steps = [
    {
      icon: Gamepad2,
      title: 'Купи GTA 5',
      description: 'Приобрети Grand Theft Auto V на официальной платформе (Steam, Epic Games или Rockstar Launcher)',
      color: 'from-[#FF3399] to-[#FF66B3]'
    },
    {
      icon: Download,
      title: 'Установи Rage MP',
      description: 'Скачай и установи мультиплеер Rage MP с официального сайта ragemp.com',
      color: 'from-[#0099FF] to-[#33ADFF]'
    },
    {
      icon: Search,
      title: 'Найди сервер',
      description: 'Запусти Rage MP, найди наш сервер в списке или подключись по IP',
      color: 'from-[#9933FF] to-[#B366FF]'
    },
    {
      icon: Play,
      title: 'Начни игру',
      description: 'Создай персонажа и погрузись в мир Saints World Role Play!',
      color: 'from-[#FF3399] to-[#0099FF]'
    }
  ];

  const news = [
    {
      title: 'Обновление 2.0: Новая эра',
      date: '15 марта 2025',
      category: 'Обновление',
      excerpt: 'Масштабное обновление с новыми системами, улучшенной экономикой и множеством новых возможностей для игроков.',
      image: 'update'
    },
    {
      title: 'Новая фракция: FIB',
      date: '10 марта 2025',
      category: 'Фракции',
      excerpt: 'Открыт набор в Федеральное Бюро Расследований. Требуются опытные игроки с хорошей репутацией.',
      image: 'faction'
    },
    {
      title: 'Ивент выходных: x2 опыт',
      date: '8 марта 2025',
      category: 'Ивент',
      excerpt: 'На этих выходных удвоенный опыт за все работы и активности на сервере!',
      image: 'event'
    }
  ];

  const features = [
    {
      icon: TrendingUp,
      title: 'Развитая экономика',
      description: 'Реалистичная экономическая система с бизнесами, недвижимостью и биржей'
    },
    {
      icon: Shield,
      title: 'Уникальные фракции',
      description: 'Полиция, FIB, мафии, банды — выбирай свой путь в мире преступности или закона'
    },
    {
      icon: Gift,
      title: 'Система наград',
      description: 'Battle Pass, достижения, ежедневные задания и уникальные бонусы'
    },
    {
      icon: Clock,
      title: '24/7 Поддержка',
      description: 'Круглосуточная техническая поддержка и активная администрация'
    }
  ];

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative min-h-screen flex items-center justify-center pt-20 overflow-hidden">
        {/* Background effects */}
        <div className="absolute inset-0 z-0">
          <div className="absolute top-1/4 left-1/4 w-[500px] h-[500px] bg-[#FF3399]/20 rounded-full blur-[150px] animate-pulse" />
          <div className="absolute bottom-1/4 right-1/4 w-[500px] h-[500px] bg-[#0099FF]/20 rounded-full blur-[150px] animate-pulse" style={{ animationDelay: '2s' }} />
        </div>

        <div className="relative z-10 w-full px-4 sm:px-6 lg:px-12 xl:px-20">
          <div className="text-center max-w-5xl mx-auto">
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
            >
              <h1 className="font-orbitron font-bold text-5xl sm:text-6xl md:text-7xl lg:text-8xl text-white mb-4 tracking-tight">
                SAINTS <span className="gradient-text">WORLD</span>
              </h1>
              <h2 className="font-orbitron font-semibold text-3xl sm:text-4xl md:text-5xl text-[#0099FF] mb-8">
                ROLE PLAY
              </h2>
            </motion.div>

            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="text-[#A0A0C0] text-lg sm:text-xl max-w-2xl mx-auto mb-10"
            >
              Погрузись в мир бесконечных возможностей Лос-Сантоса. 
              Уникальный RP-опыт с реалистичной экономикой и системой взаимодействия.
            </motion.p>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.4 }}
              className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-16"
            >
              <NeonButton to="/login" variant="primary" size="lg" icon={<Play className="w-5 h-5" />}>
                Начать игру
              </NeonButton>
              <NeonButton to="/news" variant="outline" size="lg" icon={<ArrowRight className="w-5 h-5" />}>
                Подробнее
              </NeonButton>
            </motion.div>

            {/* Server Stats */}
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.6 }}
              className="glass rounded-2xl p-6 sm:p-8 max-w-4xl mx-auto"
            >
              <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
                <div className="text-center">
                  <div className="flex items-center justify-center gap-2 mb-2">
                    <Users className="w-5 h-5 text-[#FF3399]" />
                    <span className="text-[#A0A0C0] text-sm">Онлайн</span>
                  </div>
                  <div className="font-orbitron font-bold text-2xl sm:text-3xl text-white">
                    <AnimatedCounter end={215} />
                  </div>
                </div>
                <div className="text-center">
                  <div className="flex items-center justify-center gap-2 mb-2">
                    <TrendingUp className="w-5 h-5 text-[#0099FF]" />
                    <span className="text-[#A0A0C0] text-sm">Рекорд</span>
                  </div>
                  <div className="font-orbitron font-bold text-2xl sm:text-3xl text-white">
                    <AnimatedCounter end={847} />
                  </div>
                </div>
                <div className="text-center">
                  <div className="flex items-center justify-center gap-2 mb-2">
                    <Gamepad2 className="w-5 h-5 text-[#9933FF]" />
                    <span className="text-[#A0A0C0] text-sm">Слотов</span>
                  </div>
                  <div className="font-orbitron font-bold text-2xl sm:text-3xl text-white">
                    1000
                  </div>
                </div>
                <div className="text-center">
                  <div className="flex items-center justify-center gap-2 mb-2">
                    <Copy className="w-5 h-5 text-[#FF3399]" />
                    <span className="text-[#A0A0C0] text-sm">IP</span>
                  </div>
                  <button
                    onClick={handleCopyIP}
                    className="flex items-center justify-center gap-2 mx-auto group"
                  >
                    <span className="font-mono font-bold text-lg sm:text-xl text-white group-hover:text-[#FF3399] transition-colors">
                      {serverIP}
                    </span>
                    {copied ? (
                      <Check className="w-4 h-4 text-green-400" />
                    ) : (
                      <Copy className="w-4 h-4 text-[#A0A0C0] group-hover:text-[#FF3399] transition-colors" />
                    )}
                  </button>
                </div>
              </div>

              {/* Progress bar */}
              <div className="mt-6">
                <div className="flex justify-between text-sm text-[#A0A0C0] mb-2">
                  <span>Загрузка сервера</span>
                  <span>21.5%</span>
                </div>
                <div className="progress-neon">
                  <motion.div
                    initial={{ width: 0 }}
                    animate={{ width: '21.5%' }}
                    transition={{ duration: 1.5, delay: 1, ease: 'easeOut' }}
                    className="progress-neon-fill"
                  />
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* How to Start Section */}
      <section className="py-20 sm:py-32">
        <div className="w-full px-4 sm:px-6 lg:px-12 xl:px-20">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="font-orbitron font-bold text-3xl sm:text-4xl md:text-5xl text-white mb-4">
              Как <span className="gradient-text">начать играть</span>
            </h2>
            <p className="text-[#A0A0C0] text-lg max-w-2xl mx-auto">
              Четыре простых шага отделяют тебя от мира бесконечных возможностей
            </p>
          </motion.div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {steps.map((step, index) => (
              <GlassCard key={step.title} delay={index * 0.15} glow="pink">
                <div className="relative">
                  <div className={`w-14 h-14 rounded-xl bg-gradient-to-br ${step.color} flex items-center justify-center mb-6 shadow-lg`}>
                    <step.icon className="w-7 h-7 text-white" />
                  </div>
                  <div className="absolute -top-2 -right-2 w-8 h-8 rounded-full bg-[#000022] border border-[#FF3399]/30 flex items-center justify-center">
                    <span className="font-orbitron font-bold text-sm text-[#FF3399]">{index + 1}</span>
                  </div>
                </div>
                <h3 className="font-orbitron font-semibold text-xl text-white mb-3">{step.title}</h3>
                <p className="text-[#A0A0C0] text-sm leading-relaxed">{step.description}</p>
              </GlassCard>
            ))}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 sm:py-32">
        <div className="w-full px-4 sm:px-6 lg:px-12 xl:px-20">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="font-orbitron font-bold text-3xl sm:text-4xl md:text-5xl text-white mb-4">
              Почему <span className="gradient-text">мы</span>
            </h2>
            <p className="text-[#A0A0C0] text-lg max-w-2xl mx-auto">
              Уникальные особенности, которые делают наш сервер особенным
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-4xl mx-auto">
            {features.map((feature, index) => (
              <GlassCard key={feature.title} delay={index * 0.1} glow="blue">
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-[#0099FF]/20 to-[#0099FF]/5 flex items-center justify-center flex-shrink-0">
                    <feature.icon className="w-6 h-6 text-[#0099FF]" />
                  </div>
                  <div>
                    <h3 className="font-orbitron font-semibold text-lg text-white mb-2">{feature.title}</h3>
                    <p className="text-[#A0A0C0] text-sm leading-relaxed">{feature.description}</p>
                  </div>
                </div>
              </GlassCard>
            ))}
          </div>
        </div>
      </section>

      {/* News Section */}
      <section className="py-20 sm:py-32">
        <div className="w-full px-4 sm:px-6 lg:px-12 xl:px-20">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-12">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6 }}
              viewport={{ once: true }}
            >
              <h2 className="font-orbitron font-bold text-3xl sm:text-4xl md:text-5xl text-white mb-2">
                Последние <span className="gradient-text">новости</span>
              </h2>
              <p className="text-[#A0A0C0]">Будь в курсе всех событий проекта</p>
            </motion.div>
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6 }}
              viewport={{ once: true }}
            >
              <NeonButton to="/news" variant="secondary" icon={<ArrowRight className="w-4 h-4" />}>
                Все новости
              </NeonButton>
            </motion.div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {news.map((item, index) => (
              <GlassCard key={item.title} delay={index * 0.15} glow="pink" className="overflow-hidden p-0">
                <div className="relative h-48 overflow-hidden">
                  <div className={`absolute inset-0 bg-gradient-to-br ${
                    item.image === 'update' ? 'from-[#FF3399]/30 to-[#0099FF]/30' :
                    item.image === 'faction' ? 'from-[#0099FF]/30 to-[#9933FF]/30' :
                    'from-[#9933FF]/30 to-[#FF3399]/30'
                  }`} />
                  <div className="absolute inset-0 flex items-center justify-center">
                    <Newspaper className="w-16 h-16 text-white/20" />
                  </div>
                  <div className="absolute top-4 left-4">
                    <span className="badge badge-pink">{item.category}</span>
                  </div>
                </div>
                <div className="p-6">
                  <div className="text-[#A0A0C0] text-sm mb-2">{item.date}</div>
                  <h3 className="font-orbitron font-semibold text-lg text-white mb-3 line-clamp-2">{item.title}</h3>
                  <p className="text-[#A0A0C0] text-sm line-clamp-2 mb-4">{item.excerpt}</p>
                  <button className="text-[#FF3399] text-sm font-medium flex items-center gap-2 group">
                    Читать далее
                    <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                  </button>
                </div>
              </GlassCard>
            ))}
          </div>
        </div>
      </section>

      {/* Quick Donate Section */}
      <section className="py-20 sm:py-32">
        <div className="w-full px-4 sm:px-6 lg:px-12 xl:px-20">
          <div className="max-w-5xl mx-auto">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-10 items-center">
              <motion.div
                initial={{ opacity: 0, x: -30 }}
                whileInView={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.6 }}
                viewport={{ once: true }}
              >
                <h2 className="font-orbitron font-bold text-3xl sm:text-4xl md:text-5xl text-white mb-6">
                  Поддержи <span className="gradient-text">проект</span>
                </h2>
                <p className="text-[#A0A0C0] text-lg mb-8 leading-relaxed">
                  Твоя поддержка помогает нам развивать сервер, добавлять новые функции 
                  и создавать уникальный игровой опыт для всех игроков.
                </p>
                <div className="space-y-4">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-[#FF3399]/20 to-[#FF3399]/5 flex items-center justify-center">
                      <Gift className="w-5 h-5 text-[#FF3399]" />
                    </div>
                    <span className="text-white">Уникальные бонусы и привилегии</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-[#0099FF]/20 to-[#0099FF]/5 flex items-center justify-center">
                      <TrendingUp className="w-5 h-5 text-[#0099FF]" />
                    </div>
                    <span className="text-white">Быстрый старт и развитие</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-[#9933FF]/20 to-[#9933FF]/5 flex items-center justify-center">
                      <Shield className="w-5 h-5 text-[#9933FF]" />
                    </div>
                    <span className="text-white">VIP-статус с особыми возможностями</span>
                  </div>
                </div>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, x: 30 }}
                whileInView={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.6, delay: 0.2 }}
                viewport={{ once: true }}
              >
                <GlassCard glow="pink" className="p-8">
                  <h3 className="font-orbitron font-semibold text-2xl text-white mb-6">
                    Быстрое пополнение
                  </h3>
                  <div className="mb-6">
                    <label className="block text-[#A0A0C0] text-sm mb-2">Сумма пополнения (SW Coins)</label>
                    <div className="relative">
                      <input
                        type="number"
                        value={donateAmount}
                        onChange={(e) => setDonateAmount(e.target.value)}
                        placeholder="Введите сумму"
                        className="input-glass pr-16"
                      />
                      <span className="absolute right-4 top-1/2 -translate-y-1/2 text-[#A0A0C0] text-sm">
                        SW
                      </span>
                    </div>
                  </div>
                  <div className="grid grid-cols-3 gap-3 mb-6">
                    {['100', '500', '1000'].map((amount) => (
                      <button
                        key={amount}
                        onClick={() => setDonateAmount(amount)}
                        className={`py-2 px-4 rounded-lg border transition-all duration-300 ${
                          donateAmount === amount
                            ? 'border-[#FF3399] bg-[#FF3399]/10 text-white'
                            : 'border-white/10 text-[#A0A0C0] hover:border-[#FF3399]/50 hover:text-white'
                        }`}
                      >
                        {amount}
                      </button>
                    ))}
                  </div>
                  <NeonButton variant="primary" className="w-full" icon={<Gift className="w-5 h-5" />}>
                    Пополнить
                  </NeonButton>
                  <div className="mt-6 pt-6 border-t border-white/10">
                    <p className="text-[#A0A0C0] text-sm text-center mb-4">Способы оплаты</p>
                    <div className="flex items-center justify-center gap-4">
                      <div className="w-10 h-10 rounded-lg glass flex items-center justify-center text-[#A0A0C0] text-xs font-bold">
                        FK
                      </div>
                      <div className="w-10 h-10 rounded-lg glass flex items-center justify-center text-[#A0A0C0] text-xs font-bold">
                        USDT
                      </div>
                      <div className="w-10 h-10 rounded-lg glass flex items-center justify-center text-[#A0A0C0] text-xs font-bold">
                        BTC
                      </div>
                    </div>
                  </div>
                </GlassCard>
              </motion.div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;
