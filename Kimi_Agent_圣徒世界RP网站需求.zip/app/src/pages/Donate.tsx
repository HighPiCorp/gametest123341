import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Gift, 
  TrendingUp, 
  Crown, 
  Package, 
  ShoppingCart, 
  X,
  Check,
  CreditCard,
  Bitcoin,
  ArrowRight,
  Sparkles
} from 'lucide-react';
import GlassCard from '../components/GlassCard';
import NeonButton from '../components/NeonButton';

const Donate = () => {
  const [activeCategory, setActiveCategory] = useState('swcoins');
  const [selectedItem, setSelectedItem] = useState<any>(null);
  const [showModal, setShowModal] = useState(false);
  const [paymentMethod, setPaymentMethod] = useState('freekassa');
  const [customAmount, setCustomAmount] = useState('');

  const categories = [
    { id: 'swcoins', label: 'SW Coins', icon: Gift, color: '#FF3399' },
    { id: 'bpcoins', label: 'BP Coins', icon: TrendingUp, color: '#0099FF' },
    { id: 'vip', label: 'VIP', icon: Crown, color: '#9933FF' },
    { id: 'packs', label: 'Наборы', icon: Package, color: '#22C55E' },
  ];

  const products = {
    swcoins: [
      { id: 1, name: '100 SW Coins', price: 100, bonus: 0, popular: false },
      { id: 2, name: '500 SW Coins', price: 500, bonus: 50, popular: true },
      { id: 3, name: '1000 SW Coins', price: 1000, bonus: 150, popular: false },
      { id: 4, name: '2500 SW Coins', price: 2500, bonus: 500, popular: false },
      { id: 5, name: '5000 SW Coins', price: 5000, bonus: 1250, popular: true },
      { id: 6, name: '10000 SW Coins', price: 10000, bonus: 3000, popular: false },
    ],
    bpcoins: [
      { id: 7, name: '100 BP Coins', price: 100, bonus: 0, popular: false },
      { id: 8, name: '300 BP Coins', price: 300, bonus: 30, popular: true },
      { id: 9, name: '500 BP Coins', price: 500, bonus: 75, popular: false },
      { id: 10, name: '1000 BP Coins', price: 1000, bonus: 200, popular: false },
    ],
    vip: [
      { 
        id: 11, 
        name: 'VIP Silver', 
        price: 500, 
        period: '30 дней',
        features: ['+20% к опыту', 'Уникальный скин', 'Приоритетная очередь'],
        color: 'from-gray-400 to-gray-300'
      },
      { 
        id: 12, 
        name: 'VIP Gold', 
        price: 1000, 
        period: '30 дней',
        features: ['+50% к опыту', 'Уникальный скин', 'Приоритетная очередь', 'Доступ к VIP-зонам'],
        popular: true,
        color: 'from-yellow-500 to-yellow-300'
      },
      { 
        id: 13, 
        name: 'VIP Platinum', 
        price: 2500, 
        period: '30 дней',
        features: ['+100% к опыту', 'Эксклюзивные скины', 'Мгновенный вход', 'VIP-чат', 'Особые команды'],
        color: 'from-cyan-400 to-blue-300'
      },
    ],
    packs: [
      { 
        id: 14, 
        name: 'Стартовый набор', 
        price: 300, 
        description: 'Отличный выбор для новичка',
        items: ['500 SW Coins', '100 BP Coins', 'VIP Silver (7 дней)'],
        discount: 20
      },
      { 
        id: 15, 
        name: 'Премиум набор', 
        price: 1500, 
        description: 'Максимальная выгода',
        items: ['2500 SW Coins', '500 BP Coins', 'VIP Gold (14 дней)', 'Уникальный транспорт'],
        popular: true,
        discount: 35
      },
      { 
        id: 16, 
        name: 'Бизнес-набор', 
        price: 5000, 
        description: 'Для серьёзных игроков',
        items: ['10000 SW Coins', '1500 BP Coins', 'VIP Platinum (30 дней)', 'Недвижимость в подарок'],
        discount: 40
      },
    ]
  };

  const handleBuy = (item: any) => {
    setSelectedItem(item);
    setShowModal(true);
  };

  const handleCustomAmountSubmit = () => {
    if (customAmount && parseInt(customAmount) > 0) {
      handleBuy({
        name: `${customAmount} SW Coins`,
        price: parseInt(customAmount),
        isCustom: true
      });
    }
  };

  return (
    <div className="min-h-screen pt-24 pb-10 px-4 sm:px-6 lg:px-12 xl:px-20">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="text-center mb-12"
      >
        <h1 className="font-orbitron font-bold text-4xl sm:text-5xl text-white mb-4">
          Донат <span className="gradient-text">магазин</span>
        </h1>
        <p className="text-[#A0A0C0] text-lg max-w-2xl mx-auto">
          Поддержи проект и получи уникальные бонусы, привилегии и возможности
        </p>
      </motion.div>

      {/* Categories */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, delay: 0.1 }}
        className="flex flex-wrap justify-center gap-3 mb-10"
      >
        {categories.map((cat) => (
          <button
            key={cat.id}
            onClick={() => setActiveCategory(cat.id)}
            className={`flex items-center gap-2 px-6 py-3 rounded-xl font-medium transition-all duration-300 ${
              activeCategory === cat.id
                ? 'text-white shadow-lg'
                : 'glass text-[#A0A0C0] hover:text-white'
            }`}
            style={{
              background: activeCategory === cat.id 
                ? `linear-gradient(135deg, ${cat.color}, ${cat.color}88)` 
                : undefined,
              boxShadow: activeCategory === cat.id 
                ? `0 0 30px ${cat.color}44` 
                : undefined
            }}
          >
            <cat.icon className="w-5 h-5" />
            {cat.label}
          </button>
        ))}
      </motion.div>

      {/* Custom Amount for SW Coins */}
      {activeCategory === 'swcoins' && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="max-w-md mx-auto mb-10"
        >
          <GlassCard glow="pink">
            <h3 className="font-orbitron font-semibold text-lg text-white mb-4">Произвольная сумма</h3>
            <div className="flex gap-3">
              <div className="relative flex-1">
                <input
                  type="number"
                  value={customAmount}
                  onChange={(e) => setCustomAmount(e.target.value)}
                  placeholder="Введите количество"
                  className="input-glass pr-12"
                />
                <span className="absolute right-4 top-1/2 -translate-y-1/2 text-[#A0A0C0] text-sm">SW</span>
              </div>
              <NeonButton
                variant="primary"
                onClick={handleCustomAmountSubmit}
                disabled={!customAmount || parseInt(customAmount) <= 0}
                icon={<ShoppingCart className="w-4 h-4" />}
              >
                Купить
              </NeonButton>
            </div>
          </GlassCard>
        </motion.div>
      )}

      {/* Products Grid */}
      <motion.div
        key={activeCategory}
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4 }}
        className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6"
      >
        {(products as any)[activeCategory].map((item: any, index: number) => (
          <GlassCard key={item.id} delay={index * 0.1} glow={item.popular ? 'pink' : 'none'} className="relative">
            {item.popular && (
              <div className="absolute -top-3 left-1/2 -translate-x-1/2">
                <span className="badge badge-pink flex items-center gap-1">
                  <Sparkles className="w-3 h-3" />
                  Популярное
                </span>
              </div>
            )}
            {item.discount && (
              <div className="absolute -top-3 right-4">
                <span className="badge badge-blue">-{item.discount}%</span>
              </div>
            )}

            <div className="text-center mb-4">
              {activeCategory === 'vip' ? (
                <div className={`w-16 h-16 rounded-2xl bg-gradient-to-br ${item.color} flex items-center justify-center mx-auto mb-4 shadow-lg`}>
                  <Crown className="w-8 h-8 text-white" />
                </div>
              ) : activeCategory === 'packs' ? (
                <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-[#22C55E] to-[#4ADE80] flex items-center justify-center mx-auto mb-4 shadow-lg">
                  <Package className="w-8 h-8 text-white" />
                </div>
              ) : (
                <div className={`w-16 h-16 rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-lg ${
                  activeCategory === 'swcoins' 
                    ? 'bg-gradient-to-br from-[#FF3399] to-[#FF66B3]' 
                    : 'bg-gradient-to-br from-[#0099FF] to-[#33ADFF]'
                }`}>
                  {activeCategory === 'swcoins' ? <Gift className="w-8 h-8 text-white" /> : <TrendingUp className="w-8 h-8 text-white" />}
                </div>
              )}
              <h3 className="font-orbitron font-semibold text-lg text-white">{item.name}</h3>
              {item.period && <p className="text-[#A0A0C0] text-sm">{item.period}</p>}
              {item.description && <p className="text-[#A0A0C0] text-sm">{item.description}</p>}
            </div>

            {/* Features list */}
            {(item.features || item.items) && (
              <div className="mb-4 space-y-2">
                {(item.features || item.items).map((feature: string, i: number) => (
                  <div key={i} className="flex items-center gap-2 text-sm">
                    <Check className="w-4 h-4 text-[#22C55E] flex-shrink-0" />
                    <span className="text-[#A0A0C0]">{feature}</span>
                  </div>
                ))}
              </div>
            )}

            {/* Bonus */}
            {item.bonus > 0 && (
              <div className="text-center mb-4">
                <span className="text-[#22C55E] text-sm">+{item.bonus} бонус</span>
              </div>
            )}

            <div className="flex items-center justify-between mt-auto pt-4 border-t border-white/10">
              <div>
                <span className="font-orbitron font-bold text-2xl text-white">{item.price}</span>
                <span className="text-[#A0A0C0] text-sm ml-1">SW</span>
              </div>
              <button
                onClick={() => handleBuy(item)}
                className="btn-primary py-2 px-4 text-sm"
              >
                Купить
              </button>
            </div>
          </GlassCard>
        ))}
      </motion.div>

      {/* Payment Modal */}
      <AnimatePresence>
        {showModal && selectedItem && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50"
              onClick={() => setShowModal(false)}
            />
            <motion.div
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              className="fixed inset-0 flex items-center justify-center z-50 p-4"
            >
              <div className="glass-strong rounded-3xl p-8 max-w-md w-full">
                <div className="flex items-center justify-between mb-6">
                  <h3 className="font-orbitron font-bold text-xl text-white">Подтверждение покупки</h3>
                  <button
                    onClick={() => setShowModal(false)}
                    className="p-2 rounded-lg hover:bg-white/10 transition-colors"
                  >
                    <X className="w-5 h-5 text-[#A0A0C0]" />
                  </button>
                </div>

                <div className="text-center mb-6">
                  <div className="w-20 h-20 rounded-2xl bg-gradient-to-br from-[#FF3399] to-[#0099FF] flex items-center justify-center mx-auto mb-4">
                    <ShoppingCart className="w-10 h-10 text-white" />
                  </div>
                  <h4 className="font-orbitron font-semibold text-lg text-white mb-1">{selectedItem.name}</h4>
                  <p className="font-orbitron font-bold text-3xl gradient-text">{selectedItem.price} SW</p>
                </div>

                <div className="mb-6">
                  <p className="text-[#A0A0C0] text-sm mb-3">Способ оплаты:</p>
                  <div className="space-y-2">
                    <button
                      onClick={() => setPaymentMethod('freekassa')}
                      className={`w-full flex items-center gap-3 p-4 rounded-xl border transition-all duration-300 ${
                        paymentMethod === 'freekassa'
                          ? 'border-[#FF3399] bg-[#FF3399]/10'
                          : 'border-white/10 hover:border-white/30'
                      }`}
                    >
                      <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-[#FF3399] to-[#FF66B3] flex items-center justify-center">
                        <CreditCard className="w-5 h-5 text-white" />
                      </div>
                      <div className="text-left">
                        <p className="text-white font-medium">FreeKassa</p>
                        <p className="text-[#A0A0C0] text-xs">Банковские карты, электронные кошельки</p>
                      </div>
                      {paymentMethod === 'freekassa' && <Check className="w-5 h-5 text-[#FF3399] ml-auto" />}
                    </button>

                    <button
                      onClick={() => setPaymentMethod('crypto')}
                      className={`w-full flex items-center gap-3 p-4 rounded-xl border transition-all duration-300 ${
                        paymentMethod === 'crypto'
                          ? 'border-[#0099FF] bg-[#0099FF]/10'
                          : 'border-white/10 hover:border-white/30'
                      }`}
                    >
                      <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-[#0099FF] to-[#33ADFF] flex items-center justify-center">
                        <Bitcoin className="w-5 h-5 text-white" />
                      </div>
                      <div className="text-left">
                        <p className="text-white font-medium">Криптовалюта</p>
                        <p className="text-[#A0A0C0] text-xs">USDT, BTC, ETH и другие</p>
                      </div>
                      {paymentMethod === 'crypto' && <Check className="w-5 h-5 text-[#0099FF] ml-auto" />}
                    </button>
                  </div>
                </div>

                <NeonButton variant="primary" className="w-full" icon={<ArrowRight className="w-5 h-5" />}>
                  Перейти к оплате
                </NeonButton>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </div>
  );
};

export default Donate;
