import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  ChevronDown, 
  HelpCircle, 
  Gamepad2, 
  DollarSign, 
  Shield, 
  MessageSquare,
  Search,
  Mail
} from 'lucide-react';
import GlassCard from '../components/GlassCard';
import NeonButton from '../components/NeonButton';

const FAQ = () => {
  const [openItem, setOpenItem] = useState<number | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [activeCategory, setActiveCategory] = useState('all');

  const categories = [
    { id: 'all', label: 'Все вопросы', icon: HelpCircle },
    { id: 'start', label: 'Начало игры', icon: Gamepad2 },
    { id: 'donate', label: 'Донат', icon: DollarSign },
    { id: 'rules', label: 'Правила', icon: Shield },
    { id: 'tech', label: 'Техподдержка', icon: MessageSquare },
  ];

  const faqItems = [
    {
      id: 1,
      category: 'start',
      question: 'Как начать играть на сервере?',
      answer: 'Для начала игры вам необходимо: 1) Приобрести лицензионную копию GTA 5, 2) Скачать и установить Rage MP с официального сайта ragemp.com, 3) Запустить Rage MP и найти наш сервер в списке или подключиться по IP play.saintsworld.ru, 4) Создать персонажа и начать игру!'
    },
    {
      id: 2,
      category: 'start',
      question: 'Как создать персонажа?',
      answer: 'При первом входе на сервер вам будет предложено создать персонажа. Вы сможете выбрать внешность, имя и начальные параметры. Имя должно соответствовать формату Имя_Фамилия (например, John_Smith).'
    },
    {
      id: 3,
      category: 'start',
      question: 'Какие системы есть на сервере?',
      answer: 'На нашем сервере реализованы: развитая экономическая система с бизнесами и недвижимостью, система фракций (полиция, FIB, мафии, банды), система работ с прокачкой уровней, казино с различными играми, система крафта, рыбалка, охота и многое другое!'
    },
    {
      id: 4,
      category: 'donate',
      question: 'Как пополнить баланс SW Coins?',
      answer: 'Пополнить баланс можно через личный кабинет на сайте. Мы принимаем платежи через FreeKassa (банковские карты, электронные кошельки) и криптовалюту (USDT, BTC, ETH). После оплаты монеты автоматически зачислятся на ваш аккаунт.'
    },
    {
      id: 5,
      category: 'donate',
      question: 'Что можно купить за SW Coins?',
      answer: 'За SW Coins вы можете приобрести: игровую валюту ($), VIP-статус с особыми привилегиями, уникальный транспорт, наборы услуг, уровни Battle Pass и многое другое. Полный список доступен в донат-магазине.'
    },
    {
      id: 6,
      category: 'donate',
      question: 'Как работает VIP-статус?',
      answer: 'VIP-статус даёт различные бонусы в зависимости от уровня (Silver, Gold, Platinum): увеличенный опыт, уникальные скины, приоритетную очередь на вход, доступ к VIP-зонам и многое другое. VIP действует в течение указанного срока.'
    },
    {
      id: 7,
      category: 'rules',
      question: 'Какие правила поведения на сервере?',
      answer: 'Основные правила: 1) Запрещено использование читов и стороннего ПО, 2) Обязательно соблюдение Role Play (отыгрывайте роль своего персонажа), 3) Запрещены оскорбления и токсичное поведение, 4) Запрещен DM (убийство без причины). Полные правила доступны на странице "Правила проекта".'
    },
    {
      id: 8,
      category: 'rules',
      question: 'Что такое Role Play (RP)?',
      answer: 'Role Play (RP) — это отыгрывание роли вашего персонажа. Вы должны действовать так, как бы действовал ваш персонаж в реальной жизни, а не как вы сами. Это включает в себя соблюдение законов (если вы не преступник), уважение к другим персонажам и погружение в игровой мир.'
    },
    {
      id: 9,
      category: 'rules',
      question: 'Как пожаловаться на игрока?',
      answer: 'Если вы столкнулись с нарушением правил, вы можете подать жалобу через форум в разделе "Жалобы на игроков". Обязательно предоставьте доказательства (скриншоты, видео) и подробное описание ситуации.'
    },
    {
      id: 10,
      category: 'tech',
      question: 'Игра вылетает, что делать?',
      answer: 'Если игра вылетает, попробуйте следующее: 1) Обновите Rage MP до последней версии, 2) Проверьте целостность файлов GTA 5, 3) Отключите антивирус или добавьте Rage MP в исключения, 4) Убедитесь, что ваши драйверы обновлены. Если проблема persists, обратитесь в техническую поддержку.'
    },
    {
      id: 11,
      category: 'tech',
      question: 'Не могу подключиться к серверу',
      answer: 'Проверьте следующее: 1) Запущен ли Rage MP от имени администратора, 2) Не блокирует ли файрвол подключение, 3) Работает ли сервер (проверьте статус на сайте). Если всё в порядке, попробуйте перезапустить Rage MP или обратитесь в поддержку.'
    },
    {
      id: 12,
      category: 'tech',
      question: 'Как связаться с администрацией?',
      answer: 'Связаться с администрацией можно несколькими способами: 1) Через форум в разделе "Техническая поддержка", 2) В Discord сервера, 3) Через систему репортов в игре (команда /report). Мы постараемся ответить как можно скорее!'
    },
  ];

  const filteredItems = faqItems.filter(item => {
    const matchesCategory = activeCategory === 'all' || item.category === activeCategory;
    const matchesSearch = item.question.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         item.answer.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  return (
    <div className="min-h-screen pt-24 pb-10 px-4 sm:px-6 lg:px-12 xl:px-20">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="text-center mb-10"
      >
        <h1 className="font-orbitron font-bold text-4xl sm:text-5xl text-white mb-4">
          Частые <span className="gradient-text">вопросы</span>
        </h1>
        <p className="text-[#A0A0C0] text-lg max-w-2xl mx-auto">
          Ответы на самые популярные вопросы о нашем проекте
        </p>
      </motion.div>

      {/* Search */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, delay: 0.1 }}
        className="max-w-2xl mx-auto mb-10"
      >
        <div className="relative">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-[#A0A0C0]" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Поиск по вопросам..."
            className="input-glass pl-12"
          />
        </div>
      </motion.div>

      {/* Categories */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, delay: 0.2 }}
        className="flex flex-wrap justify-center gap-2 mb-10"
      >
        {categories.map((cat) => (
          <button
            key={cat.id}
            onClick={() => setActiveCategory(cat.id)}
            className={`flex items-center gap-2 px-5 py-2.5 rounded-xl text-sm font-medium transition-all duration-300 ${
              activeCategory === cat.id
                ? 'bg-gradient-to-r from-[#FF3399] to-[#0099FF] text-white shadow-lg shadow-[#FF3399]/30'
                : 'glass text-[#A0A0C0] hover:text-white'
            }`}
          >
            <cat.icon className="w-4 h-4" />
            {cat.label}
          </button>
        ))}
      </motion.div>

      {/* FAQ Items */}
      <motion.div
        key={activeCategory + searchQuery}
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.4 }}
        className="max-w-3xl mx-auto space-y-3"
      >
        {filteredItems.map((item, index) => (
          <GlassCard key={item.id} delay={index * 0.05} glow="none" className="p-0 overflow-hidden">
            <button
              onClick={() => setOpenItem(openItem === item.id ? null : item.id)}
              className="w-full flex items-center justify-between p-5 text-left"
            >
              <span className="font-medium text-white pr-4">{item.question}</span>
              <motion.div
                animate={{ rotate: openItem === item.id ? 180 : 0 }}
                transition={{ duration: 0.3 }}
                className="flex-shrink-0"
              >
                <ChevronDown className="w-5 h-5 text-[#FF3399]" />
              </motion.div>
            </button>
            <AnimatePresence>
              {openItem === item.id && (
                <motion.div
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ height: 'auto', opacity: 1 }}
                  exit={{ height: 0, opacity: 0 }}
                  transition={{ duration: 0.3 }}
                  className="overflow-hidden"
                >
                  <div className="px-5 pb-5 pt-0">
                    <div className="border-t border-white/10 pt-4">
                      <p className="text-[#A0A0C0] leading-relaxed">{item.answer}</p>
                    </div>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </GlassCard>
        ))}
      </motion.div>

      {/* Empty State */}
      {filteredItems.length === 0 && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="text-center py-16"
        >
          <HelpCircle className="w-16 h-16 text-[#A0A0C0] mx-auto mb-4" />
          <p className="text-[#A0A0C0] text-lg mb-2">Вопросы не найдены</p>
          <p className="text-[#A0A0C0]/60 text-sm">Попробуйте изменить поисковый запрос</p>
        </motion.div>
      )}

      {/* Contact Support */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, delay: 0.4 }}
        className="max-w-2xl mx-auto mt-12"
      >
        <GlassCard glow="blue" className="text-center">
          <Mail className="w-12 h-12 text-[#0099FF] mx-auto mb-4" />
          <h3 className="font-orbitron font-semibold text-xl text-white mb-2">
            Не нашли ответ?
          </h3>
          <p className="text-[#A0A0C0] mb-6">
            Свяжитесь с нашей технической поддержкой, и мы поможем решить ваш вопрос
          </p>
          <NeonButton to="/forum" variant="primary" icon={<MessageSquare className="w-4 h-4" />}>
            Написать в поддержку
          </NeonButton>
        </GlassCard>
      </motion.div>
    </div>
  );
};

export default FAQ;
