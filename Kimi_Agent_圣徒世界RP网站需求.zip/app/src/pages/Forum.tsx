import { useState } from 'react';
import { motion } from 'framer-motion';
import { 
  MessageSquare, 
  Shield, 
  Users, 
  AlertTriangle, 
  Newspaper,
  Plus,
  Search,
  MessageCircle,
  Eye,
  Clock,
  ChevronRight,
  Lock,
  Pin
} from 'lucide-react';
import GlassCard from '../components/GlassCard';
import NeonButton from '../components/NeonButton';

const Forum = () => {
  const [activeSection, setActiveSection] = useState('general');
  const [searchQuery, setSearchQuery] = useState('');

  const sections = [
    {
      id: 'general',
      name: 'Общий раздел',
      description: 'Обсуждения, вопросы и предложения',
      icon: MessageSquare,
      color: '#FF3399',
      topics: 156,
      posts: 1243
    },
    {
      id: 'reports',
      name: 'Жалобы на игроков',
      description: 'Подайте жалобу на нарушителя',
      icon: AlertTriangle,
      color: '#EF4444',
      topics: 89,
      posts: 456
    },
    {
      id: 'factions',
      name: 'Новости фракций',
      description: 'Объявления и новости фракций',
      icon: Shield,
      color: '#0099FF',
      topics: 45,
      posts: 678,
      restricted: true
    },
    {
      id: 'news',
      name: 'Новости проекта',
      description: 'Официальные объявления',
      icon: Newspaper,
      color: '#22C55E',
      topics: 34,
      posts: 289
    },
    {
      id: 'support',
      name: 'Техническая поддержка',
      description: 'Помощь с техническими проблемами',
      icon: Users,
      color: '#9933FF',
      topics: 67,
      posts: 412
    }
  ];

  const topics = [
    {
      id: 1,
      section: 'general',
      title: 'Правила поведения на сервере - FAQ',
      author: 'Admin',
      authorAvatar: null,
      date: '15 марта 2025',
      replies: 45,
      views: 2341,
      pinned: true,
      locked: false,
      lastReply: {
        author: 'Player_One',
        date: '2 часа назад'
      }
    },
    {
      id: 2,
      section: 'general',
      title: 'Гайд для новичков: первые шаги в игре',
      author: 'Helper_Team',
      authorAvatar: null,
      date: '10 марта 2025',
      replies: 89,
      views: 4521,
      pinned: true,
      locked: false,
      lastReply: {
        author: 'Newbie_123',
        date: '5 часов назад'
      }
    },
    {
      id: 3,
      section: 'general',
      title: 'Обсуждение нового обновления 2.0',
      author: 'Veteran_Player',
      authorAvatar: null,
      date: '16 марта 2025',
      replies: 156,
      views: 3421,
      pinned: false,
      locked: false,
      lastReply: {
        author: 'Alex_RP',
        date: '30 минут назад'
      }
    },
    {
      id: 4,
      section: 'reports',
      title: 'Жалоба на DM - Player_Name',
      author: 'Victim_Player',
      authorAvatar: null,
      date: '18 марта 2025',
      replies: 3,
      views: 89,
      pinned: false,
      locked: false,
      lastReply: {
        author: 'Admin',
        date: '1 час назад'
      }
    },
    {
      id: 5,
      section: 'reports',
      title: 'Нарушение правил фракции - LSPD',
      author: 'Officer_John',
      authorAvatar: null,
      date: '17 марта 2025',
      replies: 12,
      views: 234,
      pinned: false,
      locked: true,
      lastReply: {
        author: 'LSPD_Chief',
        date: 'Вчера'
      }
    },
    {
      id: 6,
      section: 'factions',
      title: '[LSPD] Набор в полицейский департамент',
      author: 'LSPD_Chief',
      authorAvatar: null,
      date: '12 марта 2025',
      replies: 67,
      views: 1234,
      pinned: true,
      locked: false,
      lastReply: {
        author: 'Cadet_Smith',
        date: '3 часа назад'
      }
    },
    {
      id: 7,
      section: 'factions',
      title: '[La Cosa Nostra] Структура семьи',
      author: 'Don_Mario',
      authorAvatar: null,
      date: '8 марта 2025',
      replies: 23,
      views: 567,
      pinned: true,
      locked: false,
      lastReply: {
        author: 'Capo_1',
        date: 'Вчера'
      }
    },
    {
      id: 8,
      section: 'support',
      title: 'Проблема с входом в игру - Решено',
      author: 'Stuck_Player',
      authorAvatar: null,
      date: '18 марта 2025',
      replies: 5,
      views: 123,
      pinned: false,
      locked: true,
      lastReply: {
        author: 'Tech_Support',
        date: '2 часа назад'
      }
    }
  ];

  const currentSection = sections.find(s => s.id === activeSection);
  const filteredTopics = topics.filter(t => {
    const matchesSection = t.section === activeSection;
    const matchesSearch = t.title.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesSection && matchesSearch;
  });

  return (
    <div className="min-h-screen pt-24 pb-10 px-4 sm:px-6 lg:px-12 xl:px-20">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="mb-10"
      >
        <h1 className="font-orbitron font-bold text-4xl sm:text-5xl text-white mb-4">
          Форум <span className="gradient-text">сообщества</span>
        </h1>
        <p className="text-[#A0A0C0] text-lg max-w-2xl">
          Обсуждайте игру, задавайте вопросы и находите единомышленников
        </p>
      </motion.div>

      <div className="flex flex-col lg:flex-row gap-6">
        {/* Sidebar - Sections */}
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.5, delay: 0.1 }}
          className="lg:w-80 flex-shrink-0"
        >
          <div className="space-y-3">
            {sections.map((section, index) => (
              <motion.button
                key={section.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.05 }}
                onClick={() => setActiveSection(section.id)}
                className={`w-full glass rounded-xl p-4 text-left transition-all duration-300 ${
                  activeSection === section.id
                    ? 'border-[#FF3399]/50 shadow-[0_0_20px_rgba(255,51,153,0.2)]'
                    : 'hover:border-white/30'
                }`}
              >
                <div className="flex items-start gap-3">
                  <div 
                    className="w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0"
                    style={{ backgroundColor: `${section.color}20` }}
                  >
                    <section.icon className="w-5 h-5" style={{ color: section.color }} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <h3 className={`font-semibold text-sm truncate ${activeSection === section.id ? 'text-white' : 'text-[#A0A0C0]'}`}>
                        {section.name}
                      </h3>
                      {section.restricted && <Lock className="w-3 h-3 text-[#A0A0C0]" />}
                    </div>
                    <p className="text-[#A0A0C0] text-xs mt-0.5">{section.description}</p>
                    <div className="flex items-center gap-3 mt-2 text-xs text-[#A0A0C0]">
                      <span className="flex items-center gap-1">
                        <MessageSquare className="w-3 h-3" />
                        {section.topics}
                      </span>
                      <span className="flex items-center gap-1">
                        <MessageCircle className="w-3 h-3" />
                        {section.posts}
                      </span>
                    </div>
                  </div>
                  {activeSection === section.id && (
                    <ChevronRight className="w-5 h-5 text-[#FF3399] flex-shrink-0" />
                  )}
                </div>
              </motion.button>
            ))}
          </div>
        </motion.div>

        {/* Main Content */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.2 }}
          className="flex-1"
        >
          {/* Section Header */}
          <GlassCard className="mb-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div className="flex items-center gap-3">
                {currentSection && (
                  <>
                    <div 
                      className="w-12 h-12 rounded-xl flex items-center justify-center"
                      style={{ backgroundColor: `${currentSection.color}20` }}
                    >
                      <currentSection.icon className="w-6 h-6" style={{ color: currentSection.color }} />
                    </div>
                    <div>
                      <h2 className="font-orbitron font-semibold text-xl text-white">{currentSection.name}</h2>
                      <p className="text-[#A0A0C0] text-sm">{currentSection.topics} тем • {currentSection.posts} сообщений</p>
                    </div>
                  </>
                )}
              </div>
              <div className="flex items-center gap-3">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#A0A0C0]" />
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Поиск..."
                    className="input-glass pl-9 py-2 text-sm w-48"
                  />
                </div>
                <NeonButton variant="primary" size="sm" icon={<Plus className="w-4 h-4" />}>
                  Новая тема
                </NeonButton>
              </div>
            </div>
          </GlassCard>

          {/* Topics List */}
          <div className="space-y-3">
            {filteredTopics.length > 0 ? (
              filteredTopics.map((topic, index) => (
                <motion.div
                  key={topic.id}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.05 }}
                  className="glass rounded-xl p-4 hover:border-[#FF3399]/30 transition-all duration-300 cursor-pointer group"
                >
                  <div className="flex items-start gap-4">
                    {/* Status Icons */}
                    <div className="flex flex-col items-center gap-1 pt-1">
                      {topic.pinned && <Pin className="w-4 h-4 text-[#FF3399]" />}
                      {topic.locked && <Lock className="w-4 h-4 text-[#A0A0C0]" />}
                      {!topic.pinned && !topic.locked && (
                        <MessageSquare className="w-5 h-5 text-[#0099FF]" />
                      )}
                    </div>

                    {/* Content */}
                    <div className="flex-1 min-w-0">
                      <h3 className={`font-medium truncate group-hover:text-[#FF3399] transition-colors ${
                        topic.pinned ? 'text-white' : 'text-[#A0A0C0]'
                      }`}>
                        {topic.title}
                      </h3>
                      <div className="flex flex-wrap items-center gap-3 mt-2 text-xs text-[#A0A0C0]">
                        <span className="flex items-center gap-1">
                          <span className="w-5 h-5 rounded-full bg-gradient-to-br from-[#FF3399] to-[#0099FF] flex items-center justify-center text-white text-[10px] font-bold">
                            {topic.author[0]}
                          </span>
                          {topic.author}
                        </span>
                        <span className="flex items-center gap-1">
                          <Clock className="w-3 h-3" />
                          {topic.date}
                        </span>
                      </div>
                    </div>

                    {/* Stats */}
                    <div className="flex items-center gap-4 text-sm text-[#A0A0C0]">
                      <div className="flex items-center gap-1">
                        <MessageCircle className="w-4 h-4" />
                        {topic.replies}
                      </div>
                      <div className="flex items-center gap-1">
                        <Eye className="w-4 h-4" />
                        {topic.views}
                      </div>
                    </div>

                    {/* Last Reply */}
                    <div className="hidden md:block text-right text-xs text-[#A0A0C0] min-w-[120px]">
                      <p className="text-white">{topic.lastReply.author}</p>
                      <p>{topic.lastReply.date}</p>
                    </div>
                  </div>
                </motion.div>
              ))
            ) : (
              <GlassCard className="text-center py-12">
                <MessageSquare className="w-12 h-12 text-[#A0A0C0] mx-auto mb-4" />
                <p className="text-[#A0A0C0]">Темы не найдены</p>
              </GlassCard>
            )}
          </div>
        </motion.div>
      </div>
    </div>
  );
};

export default Forum;
