import { useState } from 'react';
import { motion } from 'framer-motion';
import { 
  Calendar, 
  ArrowRight, 
  User, 
  Tag,
  ChevronLeft,
  Share2,
  MessageSquare,
  Eye
} from 'lucide-react';
import GlassCard from '../components/GlassCard';
import NeonButton from '../components/NeonButton';

const News = () => {
  const [selectedNews, setSelectedNews] = useState<any>(null);
  const [activeCategory, setActiveCategory] = useState('all');

  const categories = [
    { id: 'all', label: 'Все' },
    { id: 'updates', label: 'Обновления' },
    { id: 'events', label: 'Ивенты' },
    { id: 'factions', label: 'Фракции' },
    { id: 'other', label: 'Другое' },
  ];

  const newsItems = [
    {
      id: 1,
      title: 'Обновление 2.0: Новая эра Saints World',
      excerpt: 'Масштабное обновление с новыми системами, улучшенной экономикой и множеством новых возможностей для игроков. Мы полностью переработали систему фракций, добавили новые виды бизнеса и значительно расширили карту.',
      content: `
        <p>Дорогие игроки!</p>
        <p>Мы рады представить вам масштабное обновление 2.0, которое полностью изменит ваш игровой опыт в Saints World Role Play.</p>
        <h3>Что нового:</h3>
        <ul>
          <li>Полностью переработанная система фракций с новыми рангами и возможностями</li>
          <li>Новые виды бизнеса: от казино до ночных клубов</li>
          <li>Расширенная карта с новыми локациями</li>
          <li>Улучшенная система крафта и кража транспорта</li>
          <li>Новые системы работ с уникальными механиками</li>
        </ul>
        <p>Спасибо, что остаетесь с нами!</p>
      `,
      date: '15 марта 2025',
      author: 'Admin',
      category: 'updates',
      categoryLabel: 'Обновление',
      views: 3245,
      comments: 89,
      image: 'update'
    },
    {
      id: 2,
      title: 'Новая фракция: FIB открывает набор',
      excerpt: 'Федеральное Бюро Расследований начинает набор агентов. Требуются опытные игроки с хорошей репутацией и желанием бороться с преступностью.',
      content: `
        <p>Федеральное Бюро Расследований объявляет о начале набора в свои ряды!</p>
        <h3>Требования к кандидатам:</h3>
        <ul>
          <li>Уровень персонажа 20+</li>
          <li>Отсутствие серьёзных нарушений в истории</li>
          <li>Опыт игры на RP-серверах</li>
          <li>Готовность к обучению</li>
        </ul>
        <p>Подай заявку уже сегодня!</p>
      `,
      date: '10 марта 2025',
      author: 'FIB_Leadership',
      category: 'factions',
      categoryLabel: 'Фракции',
      views: 2156,
      comments: 45,
      image: 'faction'
    },
    {
      id: 3,
      title: 'Ивент выходных: x2 опыт за все работы',
      excerpt: 'На этих выходных удвоенный опыт за все работы и активности на сервере! Не упустите шанс прокачать своего персонажа быстрее.',
      content: `
        <p>Внимание всем игрокам!</p>
        <p>С субботы 00:00 до воскресенья 23:59 действует акция: x2 опыт за все виды работ и активности на сервере!</p>
        <p>Это отличная возможность быстро прокачать уровень своего персонажа и открыть новые возможности.</p>
        <p>Удачной игры!</p>
      `,
      date: '8 марта 2025',
      author: 'Event_Team',
      category: 'events',
      categoryLabel: 'Ивент',
      views: 4521,
      comments: 123,
      image: 'event'
    },
    {
      id: 4,
      title: 'Новая система недвижимости',
      excerpt: 'Мы полностью переработали систему покупки и управления недвижимостью. Теперь вы можете арендовать свои дома и управлять ими через личный кабинет.',
      content: `
        <p>Обновление системы недвижимости уже на сервере!</p>
        <h3>Новые возможности:</h3>
        <ul>
          <li>Аренда своих домов другим игрокам</li>
          <li>Управление доступом в дом</li>
          <li>Система сожителей</li>
          <li>Улучшенный интерфейс покупки</li>
        </ul>
      `,
      date: '5 марта 2025',
      author: 'Dev_Team',
      category: 'updates',
      categoryLabel: 'Обновление',
      views: 1876,
      comments: 34,
      image: 'update'
    },
    {
      id: 5,
      title: 'Турнир по гонкам с призовым фондом',
      excerpt: 'Приглашаем всех участвовать в турнире по уличным гонкам. Призовой фонд составляет 5 000 000$!',
      content: `
        <p>Гоночный турнир уже в эту субботу!</p>
        <h3>Призовой фонд:</h3>
        <ul>
          <li>1 место: 3 000 000$</li>
          <li>2 место: 1 500 000$</li>
          <li>3 место: 500 000$</li>
        </ul>
        <p>Регистрация открыта до пятницы 20:00.</p>
      `,
      date: '3 марта 2025',
      author: 'Event_Team',
      category: 'events',
      categoryLabel: 'Ивент',
      views: 5632,
      comments: 201,
      image: 'event'
    },
    {
      id: 6,
      title: 'Новые автомобили в автосалонах',
      excerpt: 'В наши автосалоны поступили новые модели транспорта. Успейте приобрести эксклюзивные авто по специальным ценам.',
      content: `
        <p>Новое пополнение в автосалонах!</p>
        <p>Теперь доступны для покупки:</p>
        <ul>
          <li>Infernus Classic - 3 500 000$</li>
          <li>Cheetah Retro - 2 800 000$</li>
          <li>Turismo Custom - 4 200 000$</li>
        </ul>
        <p>Специальные цены действуют до конца недели!</p>
      `,
      date: '1 марта 2025',
      author: 'Admin',
      category: 'other',
      categoryLabel: 'Другое',
      views: 2890,
      comments: 67,
      image: 'other'
    },
  ];

  const filteredNews = activeCategory === 'all' 
    ? newsItems 
    : newsItems.filter(item => item.category === activeCategory);

  if (selectedNews) {
    return (
      <div className="min-h-screen pt-24 pb-10 px-4 sm:px-6 lg:px-12 xl:px-20">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <button
            onClick={() => setSelectedNews(null)}
            className="flex items-center gap-2 text-[#A0A0C0] hover:text-white transition-colors mb-6"
          >
            <ChevronLeft className="w-5 h-5" />
            Назад к новостям
          </button>

          <article className="max-w-4xl mx-auto">
            {/* Hero Image */}
            <div className={`relative h-64 sm:h-80 rounded-2xl overflow-hidden mb-8 ${
              selectedNews.image === 'update' ? 'bg-gradient-to-br from-[#FF3399]/30 to-[#0099FF]/30' :
              selectedNews.image === 'faction' ? 'bg-gradient-to-br from-[#0099FF]/30 to-[#9933FF]/30' :
              selectedNews.image === 'event' ? 'bg-gradient-to-br from-[#9933FF]/30 to-[#FF3399]/30' :
              'bg-gradient-to-br from-[#22C55E]/30 to-[#0099FF]/30'
            }`}>
              <div className="absolute inset-0 flex items-center justify-center">
                <Tag className="w-24 h-24 text-white/20" />
              </div>
              <div className="absolute inset-0 bg-gradient-to-t from-[#000022] via-transparent to-transparent" />
              <div className="absolute bottom-6 left-6 right-6">
                <span className="badge badge-pink mb-3">{selectedNews.categoryLabel}</span>
                <h1 className="font-orbitron font-bold text-2xl sm:text-4xl text-white">{selectedNews.title}</h1>
              </div>
            </div>

            {/* Meta */}
            <div className="flex flex-wrap items-center gap-4 mb-8 text-[#A0A0C0] text-sm">
              <div className="flex items-center gap-2">
                <User className="w-4 h-4" />
                {selectedNews.author}
              </div>
              <div className="flex items-center gap-2">
                <Calendar className="w-4 h-4" />
                {selectedNews.date}
              </div>
              <div className="flex items-center gap-2">
                <Eye className="w-4 h-4" />
                {selectedNews.views} просмотров
              </div>
              <div className="flex items-center gap-2">
                <MessageSquare className="w-4 h-4" />
                {selectedNews.comments} комментариев
              </div>
            </div>

            {/* Content */}
            <GlassCard className="prose prose-invert max-w-none">
              <div 
                className="text-[#A0A0C0] leading-relaxed space-y-4"
                dangerouslySetInnerHTML={{ __html: selectedNews.content }}
              />
            </GlassCard>

            {/* Share */}
            <div className="mt-8 flex items-center justify-between">
              <NeonButton variant="outline" onClick={() => setSelectedNews(null)} icon={<ChevronLeft className="w-4 h-4" />}>
                Назад
              </NeonButton>
              <button className="flex items-center gap-2 text-[#A0A0C0] hover:text-[#FF3399] transition-colors">
                <Share2 className="w-5 h-5" />
                Поделиться
              </button>
            </div>
          </article>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="min-h-screen pt-24 pb-10 px-4 sm:px-6 lg:px-12 xl:px-20">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="text-center mb-10"
      >
        <h1 className="font-orbitron font-bold text-4xl sm:text-5xl text-white mb-4">
          Новости <span className="gradient-text">проекта</span>
        </h1>
        <p className="text-[#A0A0C0] text-lg max-w-2xl mx-auto">
          Будь в курсе всех обновлений, ивентов и важных событий сервера
        </p>
      </motion.div>

      {/* Categories */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, delay: 0.1 }}
        className="flex flex-wrap justify-center gap-2 mb-10"
      >
        {categories.map((cat) => (
          <button
            key={cat.id}
            onClick={() => setActiveCategory(cat.id)}
            className={`px-5 py-2 rounded-full text-sm font-medium transition-all duration-300 ${
              activeCategory === cat.id
                ? 'bg-gradient-to-r from-[#FF3399] to-[#0099FF] text-white shadow-lg shadow-[#FF3399]/30'
                : 'glass text-[#A0A0C0] hover:text-white'
            }`}
          >
            {cat.label}
          </button>
        ))}
      </motion.div>

      {/* News Grid */}
      <motion.div
        key={activeCategory}
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.4 }}
        className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
      >
        {filteredNews.map((item, index) => (
          <GlassCard 
            key={item.id} 
            delay={index * 0.1} 
            glow="pink" 
            className="cursor-pointer overflow-hidden p-0"
            onClick={() => setSelectedNews(item)}
          >
            {/* Image */}
            <div className={`relative h-48 overflow-hidden ${
              item.image === 'update' ? 'bg-gradient-to-br from-[#FF3399]/30 to-[#0099FF]/30' :
              item.image === 'faction' ? 'bg-gradient-to-br from-[#0099FF]/30 to-[#9933FF]/30' :
              item.image === 'event' ? 'bg-gradient-to-br from-[#9933FF]/30 to-[#FF3399]/30' :
              'bg-gradient-to-br from-[#22C55E]/30 to-[#0099FF]/30'
            }`}>
              <div className="absolute inset-0 flex items-center justify-center">
                <Tag className="w-16 h-16 text-white/20" />
              </div>
              <div className="absolute top-4 left-4">
                <span className="badge badge-pink">{item.categoryLabel}</span>
              </div>
              <div className="absolute inset-0 bg-gradient-to-t from-[#000022]/80 to-transparent" />
            </div>

            {/* Content */}
            <div className="p-6">
              <div className="flex items-center gap-3 text-[#A0A0C0] text-xs mb-3">
                <span className="flex items-center gap-1">
                  <Calendar className="w-3 h-3" />
                  {item.date}
                </span>
                <span className="flex items-center gap-1">
                  <Eye className="w-3 h-3" />
                  {item.views}
                </span>
              </div>

              <h3 className="font-orbitron font-semibold text-lg text-white mb-3 line-clamp-2 hover:text-[#FF3399] transition-colors">
                {item.title}
              </h3>

              <p className="text-[#A0A0C0] text-sm line-clamp-2 mb-4">
                {item.excerpt}
              </p>

              <button className="flex items-center gap-2 text-[#FF3399] text-sm font-medium group">
                Читать далее
                <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </button>
            </div>
          </GlassCard>
        ))}
      </motion.div>

      {/* Empty State */}
      {filteredNews.length === 0 && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="text-center py-20"
        >
          <Tag className="w-16 h-16 text-[#A0A0C0] mx-auto mb-4" />
          <p className="text-[#A0A0C0] text-lg">Новости в этой категории пока отсутствуют</p>
        </motion.div>
      )}
    </div>
  );
};

export default News;
