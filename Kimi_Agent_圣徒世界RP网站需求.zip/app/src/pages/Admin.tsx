import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  LayoutDashboard, 
  Users, 
  ShoppingCart, 
  Gift, 
  MessageSquare,
  Settings,
  LogOut,
  ChevronRight,
  TrendingUp,
  TrendingDown,
  DollarSign,
  UserPlus,
  AlertCircle,
  Search,
  Filter,
  MoreVertical,
  Plus,
  X,
  Edit3,
  Ban,
  Eye
} from 'lucide-react';
import GlassCard from '../components/GlassCard';
import NeonButton from '../components/NeonButton';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, AreaChart, Area } from 'recharts';

const Admin = () => {
  const [activeTab, setActiveTab] = useState('dashboard');
  const [showUserModal, setShowUserModal] = useState(false);
  const [selectedUser, setSelectedUser] = useState<any>(null);

  const sidebarItems = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'users', label: 'Пользователи', icon: Users },
    { id: 'transactions', label: 'Транзакции', icon: ShoppingCart },
    { id: 'promocodes', label: 'Промокоды', icon: Gift },
    { id: 'reports', label: 'Репорты', icon: MessageSquare },
    { id: 'settings', label: 'Настройки', icon: Settings },
  ];

  // Mock data for charts
  const onlineData = [
    { time: '00:00', online: 120 },
    { time: '04:00', online: 80 },
    { time: '08:00', online: 150 },
    { time: '12:00', online: 280 },
    { time: '16:00', online: 320 },
    { time: '20:00', online: 450 },
    { time: '23:59', online: 380 },
  ];

  const donateData = [
    { day: 'Пн', amount: 15000 },
    { day: 'Вт', amount: 22000 },
    { day: 'Ср', amount: 18000 },
    { day: 'Чт', amount: 25000 },
    { day: 'Пт', amount: 32000 },
    { day: 'Сб', amount: 45000 },
    { day: 'Вс', amount: 38000 },
  ];

  const stats = [
    { 
      label: 'Онлайн сейчас', 
      value: '215', 
      change: '+12%', 
      trend: 'up',
      icon: Users,
      color: '#FF3399'
    },
    { 
      label: 'Новых за 24ч', 
      value: '47', 
      change: '+23%', 
      trend: 'up',
      icon: UserPlus,
      color: '#0099FF'
    },
    { 
      label: 'Донат сегодня', 
      value: '38,500 SW', 
      change: '+45%', 
      trend: 'up',
      icon: DollarSign,
      color: '#22C55E'
    },
    { 
      label: 'Активных репортов', 
      value: '12', 
      change: '-3', 
      trend: 'down',
      icon: AlertCircle,
      color: '#EF4444'
    },
  ];

  const users = [
    { id: 1, name: 'Alex_Rodriguez', email: 'alex@example.com', swCoins: 1250, bpCoins: 450, status: 'active', registerDate: '15.01.2025', lastLogin: 'Сегодня' },
    { id: 2, name: 'Marcus_Stone', email: 'marcus@example.com', swCoins: 500, bpCoins: 200, status: 'active', registerDate: '20.01.2025', lastLogin: 'Вчера' },
    { id: 3, name: 'Sarah_Johnson', email: 'sarah@example.com', swCoins: 0, bpCoins: 0, status: 'banned', registerDate: '01.02.2025', lastLogin: '3 дня назад' },
    { id: 4, name: 'Mike_Williams', email: 'mike@example.com', swCoins: 5000, bpCoins: 1200, status: 'active', registerDate: '10.02.2025', lastLogin: 'Сегодня' },
    { id: 5, name: 'Emma_Davis', email: 'emma@example.com', swCoins: 100, bpCoins: 50, status: 'active', registerDate: '15.02.2025', lastLogin: 'Неделю назад' },
  ];

  const transactions = [
    { id: 1, user: 'Alex_Rodriguez', type: 'Пополнение', amount: '+500 SW', method: 'FreeKassa', status: 'completed', date: '18.03.2025 14:30' },
    { id: 2, user: 'Marcus_Stone', type: 'Покупка VIP', amount: '-1000 SW', method: 'SW Coins', status: 'completed', date: '18.03.2025 12:15' },
    { id: 3, user: 'Mike_Williams', type: 'Пополнение', amount: '+5000 SW', method: 'Crypto', status: 'pending', date: '18.03.2025 10:00' },
    { id: 4, user: 'Emma_Davis', type: 'Покупка набора', amount: '-300 SW', method: 'SW Coins', status: 'completed', date: '17.03.2025 20:45' },
  ];

  const promocodes = [
    { id: 1, code: 'WELCOME2025', reward: '100 SW', uses: 45, maxUses: 100, expires: '31.03.2025', status: 'active' },
    { id: 2, code: 'SPRINGEVENT', reward: 'VIP Silver (7 дней)', uses: 23, maxUses: 50, expires: '25.03.2025', status: 'active' },
    { id: 3, code: 'OLDBONUS', reward: '500 BP', uses: 100, maxUses: 100, expires: '01.03.2025', status: 'expired' },
  ];

  const reports = [
    { id: 1, title: 'Жалоба на DM', author: 'Victim_Player', category: 'Жалоба', status: 'new', date: '18.03.2025' },
    { id: 2, title: 'Баг с инвентарем', author: 'Bug_Hunter', category: 'Баг', status: 'in_progress', date: '17.03.2025' },
    { id: 3, title: 'Вопрос о донате', author: 'New_Player', category: 'Вопрос', status: 'closed', date: '16.03.2025' },
  ];

  const handleUserClick = (user: any) => {
    setSelectedUser(user);
    setShowUserModal(true);
  };

  const renderDashboard = () => (
    <div className="space-y-6">
      {/* Stats Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map((stat, index) => (
          <GlassCard key={stat.label} delay={index * 0.1} glow={stat.trend === 'up' ? 'pink' : 'none'}>
            <div className="flex items-start justify-between">
              <div>
                <p className="text-[#A0A0C0] text-sm mb-1">{stat.label}</p>
                <p className="font-orbitron font-bold text-2xl text-white">{stat.value}</p>
                <div className={`flex items-center gap-1 mt-2 text-sm ${
                  stat.trend === 'up' ? 'text-green-400' : 'text-red-400'
                }`}>
                  {stat.trend === 'up' ? <TrendingUp className="w-4 h-4" /> : <TrendingDown className="w-4 h-4" />}
                  {stat.change}
                </div>
              </div>
              <div 
                className="w-12 h-12 rounded-xl flex items-center justify-center"
                style={{ backgroundColor: `${stat.color}20` }}
              >
                <stat.icon className="w-6 h-6" style={{ color: stat.color }} />
              </div>
            </div>
          </GlassCard>
        ))}
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <GlassCard>
          <h3 className="font-orbitron font-semibold text-lg text-white mb-4">Онлайн за сутки</h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={onlineData}>
                <defs>
                  <linearGradient id="colorOnline" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#FF3399" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="#FF3399" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.1)" />
                <XAxis dataKey="time" stroke="#A0A0C0" fontSize={12} />
                <YAxis stroke="#A0A0C0" fontSize={12} />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: '#0a0a1a', 
                    border: '1px solid rgba(255,51,153,0.3)',
                    borderRadius: '8px'
                  }}
                />
                <Area type="monotone" dataKey="online" stroke="#FF3399" fillOpacity={1} fill="url(#colorOnline)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </GlassCard>

        <GlassCard>
          <h3 className="font-orbitron font-semibold text-lg text-white mb-4">Донат за неделю</h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={donateData}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.1)" />
                <XAxis dataKey="day" stroke="#A0A0C0" fontSize={12} />
                <YAxis stroke="#A0A0C0" fontSize={12} />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: '#0a0a1a', 
                    border: '1px solid rgba(0,153,255,0.3)',
                    borderRadius: '8px'
                  }}
                />
                <Line type="monotone" dataKey="amount" stroke="#0099FF" strokeWidth={2} dot={{ fill: '#0099FF' }} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </GlassCard>
      </div>

      {/* Recent Activity */}
      <GlassCard>
        <h3 className="font-orbitron font-semibold text-lg text-white mb-4">Последние транзакции</h3>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-white/10">
                <th className="text-left py-3 px-4 text-[#A0A0C0] text-sm font-medium">Пользователь</th>
                <th className="text-left py-3 px-4 text-[#A0A0C0] text-sm font-medium">Тип</th>
                <th className="text-left py-3 px-4 text-[#A0A0C0] text-sm font-medium">Сумма</th>
                <th className="text-left py-3 px-4 text-[#A0A0C0] text-sm font-medium">Способ</th>
                <th className="text-left py-3 px-4 text-[#A0A0C0] text-sm font-medium">Статус</th>
                <th className="text-left py-3 px-4 text-[#A0A0C0] text-sm font-medium">Дата</th>
              </tr>
            </thead>
            <tbody>
              {transactions.slice(0, 5).map((t) => (
                <tr key={t.id} className="border-b border-white/5 hover:bg-white/5 transition-colors">
                  <td className="py-3 px-4 text-white text-sm">{t.user}</td>
                  <td className="py-3 px-4 text-[#A0A0C0] text-sm">{t.type}</td>
                  <td className={`py-3 px-4 font-mono text-sm ${t.amount.startsWith('+') ? 'text-green-400' : 'text-red-400'}`}>
                    {t.amount}
                  </td>
                  <td className="py-3 px-4 text-[#A0A0C0] text-sm">{t.method}</td>
                  <td className="py-3 px-4">
                    <span className={`badge text-xs ${
                      t.status === 'completed' ? 'badge-blue' : 
                      t.status === 'pending' ? 'badge-pink' : ''
                    }`}>
                      {t.status === 'completed' ? 'Выполнено' : 'В обработке'}
                    </span>
                  </td>
                  <td className="py-3 px-4 text-[#A0A0C0] text-sm">{t.date}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </GlassCard>
    </div>
  );

  const renderUsers = () => (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <h2 className="font-orbitron font-bold text-2xl text-white">Пользователи</h2>
        <div className="flex items-center gap-3">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#A0A0C0]" />
            <input type="text" placeholder="Поиск..." className="input-glass pl-9 py-2 text-sm w-48" />
          </div>
          <button className="p-2 rounded-lg glass hover:border-[#FF3399]/50 transition-colors">
            <Filter className="w-4 h-4 text-[#A0A0C0]" />
          </button>
        </div>
      </div>

      <GlassCard className="overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-white/10">
                <th className="text-left py-3 px-4 text-[#A0A0C0] text-sm font-medium">Имя</th>
                <th className="text-left py-3 px-4 text-[#A0A0C0] text-sm font-medium">Email</th>
                <th className="text-left py-3 px-4 text-[#A0A0C0] text-sm font-medium">SW Coins</th>
                <th className="text-left py-3 px-4 text-[#A0A0C0] text-sm font-medium">BP Coins</th>
                <th className="text-left py-3 px-4 text-[#A0A0C0] text-sm font-medium">Статус</th>
                <th className="text-left py-3 px-4 text-[#A0A0C0] text-sm font-medium">Регистрация</th>
                <th className="text-left py-3 px-4 text-[#A0A0C0] text-sm font-medium">Действия</th>
              </tr>
            </thead>
            <tbody>
              {users.map((user) => (
                <tr key={user.id} className="border-b border-white/5 hover:bg-white/5 transition-colors">
                  <td className="py-3 px-4">
                    <button 
                      onClick={() => handleUserClick(user)}
                      className="text-white text-sm hover:text-[#FF3399] transition-colors"
                    >
                      {user.name}
                    </button>
                  </td>
                  <td className="py-3 px-4 text-[#A0A0C0] text-sm">{user.email}</td>
                  <td className="py-3 px-4 text-white text-sm font-mono">{user.swCoins}</td>
                  <td className="py-3 px-4 text-white text-sm font-mono">{user.bpCoins}</td>
                  <td className="py-3 px-4">
                    <span className={`badge text-xs ${
                      user.status === 'active' ? 'badge-blue' : 'bg-red-500/20 text-red-400 border-red-500/30'
                    }`}>
                      {user.status === 'active' ? 'Активен' : 'Заблокирован'}
                    </span>
                  </td>
                  <td className="py-3 px-4 text-[#A0A0C0] text-sm">{user.registerDate}</td>
                  <td className="py-3 px-4">
                    <div className="flex items-center gap-2">
                      <button className="p-1.5 rounded-lg hover:bg-white/10 transition-colors" title="Редактировать">
                        <Edit3 className="w-4 h-4 text-[#A0A0C0]" />
                      </button>
                      <button className="p-1.5 rounded-lg hover:bg-white/10 transition-colors" title="Заблокировать">
                        <Ban className="w-4 h-4 text-red-400" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </GlassCard>
    </div>
  );

  const renderTransactions = () => (
    <div className="space-y-6">
      <h2 className="font-orbitron font-bold text-2xl text-white">Транзакции</h2>
      <GlassCard className="overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-white/10">
                <th className="text-left py-3 px-4 text-[#A0A0C0] text-sm font-medium">ID</th>
                <th className="text-left py-3 px-4 text-[#A0A0C0] text-sm font-medium">Пользователь</th>
                <th className="text-left py-3 px-4 text-[#A0A0C0] text-sm font-medium">Тип</th>
                <th className="text-left py-3 px-4 text-[#A0A0C0] text-sm font-medium">Сумма</th>
                <th className="text-left py-3 px-4 text-[#A0A0C0] text-sm font-medium">Способ</th>
                <th className="text-left py-3 px-4 text-[#A0A0C0] text-sm font-medium">Статус</th>
                <th className="text-left py-3 px-4 text-[#A0A0C0] text-sm font-medium">Дата</th>
              </tr>
            </thead>
            <tbody>
              {transactions.map((t) => (
                <tr key={t.id} className="border-b border-white/5 hover:bg-white/5 transition-colors">
                  <td className="py-3 px-4 text-[#A0A0C0] text-sm">#{t.id}</td>
                  <td className="py-3 px-4 text-white text-sm">{t.user}</td>
                  <td className="py-3 px-4 text-[#A0A0C0] text-sm">{t.type}</td>
                  <td className={`py-3 px-4 font-mono text-sm ${t.amount.startsWith('+') ? 'text-green-400' : 'text-red-400'}`}>
                    {t.amount}
                  </td>
                  <td className="py-3 px-4 text-[#A0A0C0] text-sm">{t.method}</td>
                  <td className="py-3 px-4">
                    <span className={`badge text-xs ${
                      t.status === 'completed' ? 'badge-blue' : 'badge-pink'
                    }`}>
                      {t.status === 'completed' ? 'Выполнено' : 'В обработке'}
                    </span>
                  </td>
                  <td className="py-3 px-4 text-[#A0A0C0] text-sm">{t.date}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </GlassCard>
    </div>
  );

  const renderPromocodes = () => (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="font-orbitron font-bold text-2xl text-white">Промокоды</h2>
        <NeonButton variant="primary" size="sm" icon={<Plus className="w-4 h-4" />}>
          Создать
        </NeonButton>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {promocodes.map((promo, index) => (
          <GlassCard key={promo.id} delay={index * 0.1} glow={promo.status === 'active' ? 'pink' : 'none'}>
            <div className="flex items-start justify-between mb-4">
              <div>
                <h3 className="font-orbitron font-semibold text-lg text-white">{promo.code}</h3>
                <p className="text-[#A0A0C0] text-sm">{promo.reward}</p>
              </div>
              <span className={`badge text-xs ${
                promo.status === 'active' ? 'badge-blue' : 'bg-gray-500/20 text-gray-400 border-gray-500/30'
              }`}>
                {promo.status === 'active' ? 'Активен' : 'Истёк'}
              </span>
            </div>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-[#A0A0C0]">Использований</span>
                <span className="text-white">{promo.uses}/{promo.maxUses}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-[#A0A0C0]">Истекает</span>
                <span className="text-white">{promo.expires}</span>
              </div>
            </div>
            <div className="mt-4 pt-4 border-t border-white/10 flex items-center justify-between">
              <div className="progress-neon h-1.5 flex-1 mr-4">
                <div 
                  className="progress-neon-fill" 
                  style={{ width: `${(promo.uses / promo.maxUses) * 100}%` }} 
                />
              </div>
              <button className="p-1.5 rounded-lg hover:bg-white/10 transition-colors">
                <MoreVertical className="w-4 h-4 text-[#A0A0C0]" />
              </button>
            </div>
          </GlassCard>
        ))}
      </div>
    </div>
  );

  const renderReports = () => (
    <div className="space-y-6">
      <h2 className="font-orbitron font-bold text-2xl text-white">Репорты</h2>
      <div className="space-y-3">
        {reports.map((report, index) => (
          <GlassCard key={report.id} delay={index * 0.05} glow="none" className="p-4">
            <div className="flex items-start justify-between">
              <div className="flex items-start gap-4">
                <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${
                  report.status === 'new' ? 'bg-red-500/20' :
                  report.status === 'in_progress' ? 'bg-yellow-500/20' : 'bg-green-500/20'
                }`}>
                  <AlertCircle className={`w-5 h-5 ${
                    report.status === 'new' ? 'text-red-400' :
                    report.status === 'in_progress' ? 'text-yellow-400' : 'text-green-400'
                  }`} />
                </div>
                <div>
                  <h3 className="font-medium text-white">{report.title}</h3>
                  <div className="flex items-center gap-3 mt-1 text-xs text-[#A0A0C0]">
                    <span>{report.author}</span>
                    <span>•</span>
                    <span>{report.category}</span>
                    <span>•</span>
                    <span>{report.date}</span>
                  </div>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <span className={`badge text-xs ${
                  report.status === 'new' ? 'bg-red-500/20 text-red-400 border-red-500/30' :
                  report.status === 'in_progress' ? 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30' :
                  'badge-blue'
                }`}>
                  {report.status === 'new' ? 'Новый' : report.status === 'in_progress' ? 'В работе' : 'Закрыт'}
                </span>
                <button className="p-1.5 rounded-lg hover:bg-white/10 transition-colors">
                  <Eye className="w-4 h-4 text-[#A0A0C0]" />
                </button>
              </div>
            </div>
          </GlassCard>
        ))}
      </div>
    </div>
  );

  return (
    <div className="min-h-screen pt-24 pb-10 px-4 sm:px-6 lg:px-12 xl:px-20">
      <div className="flex flex-col lg:flex-row gap-6">
        {/* Sidebar */}
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.5 }}
          className="lg:w-64 flex-shrink-0"
        >
          <div className="glass rounded-2xl p-4 sticky top-24">
            {/* Admin info */}
            <div className="flex items-center gap-3 mb-6 pb-6 border-b border-white/10">
              <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-[#FF3399] to-[#0099FF] flex items-center justify-center">
                <span className="font-orbitron font-bold text-white">A</span>
              </div>
              <div>
                <p className="font-semibold text-white text-sm">Admin</p>
                <p className="text-[#A0A0C0] text-xs">Администратор</p>
              </div>
            </div>

            {/* Navigation */}
            <nav className="space-y-1">
              {sidebarItems.map((item) => (
                <button
                  key={item.id}
                  onClick={() => setActiveTab(item.id)}
                  className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-300 ${
                    activeTab === item.id
                      ? 'bg-gradient-to-r from-[#FF3399]/20 to-[#0099FF]/20 border border-[#FF3399]/30 text-white'
                      : 'text-[#A0A0C0] hover:text-white hover:bg-white/5'
                  }`}
                >
                  <item.icon className={`w-5 h-5 ${activeTab === item.id ? 'text-[#FF3399]' : ''}`} />
                  <span className="text-sm">{item.label}</span>
                  {activeTab === item.id && <ChevronRight className="w-4 h-4 ml-auto" />}
                </button>
              ))}
            </nav>

            {/* Logout */}
            <button className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-red-400 hover:bg-red-500/10 transition-all duration-300 mt-6">
              <LogOut className="w-5 h-5" />
              <span className="text-sm">Выйти</span>
            </button>
          </div>
        </motion.div>

        {/* Main Content */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.1 }}
          className="flex-1"
        >
          <AnimatePresence mode="wait">
            <motion.div
              key={activeTab}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.3 }}
            >
              {activeTab === 'dashboard' && renderDashboard()}
              {activeTab === 'users' && renderUsers()}
              {activeTab === 'transactions' && renderTransactions()}
              {activeTab === 'promocodes' && renderPromocodes()}
              {activeTab === 'reports' && renderReports()}
            </motion.div>
          </AnimatePresence>
        </motion.div>
      </div>

      {/* User Modal */}
      <AnimatePresence>
        {showUserModal && selectedUser && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50"
              onClick={() => setShowUserModal(false)}
            />
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              className="fixed inset-0 flex items-center justify-center z-50 p-4"
            >
              <div className="glass-strong rounded-3xl p-8 max-w-md w-full">
                <div className="flex items-center justify-between mb-6">
                  <h3 className="font-orbitron font-bold text-xl text-white">Пользователь</h3>
                  <button onClick={() => setShowUserModal(false)} className="p-2 rounded-lg hover:bg-white/10">
                    <X className="w-5 h-5 text-[#A0A0C0]" />
                  </button>
                </div>
                <div className="text-center mb-6">
                  <div className="w-20 h-20 rounded-2xl bg-gradient-to-br from-[#FF3399] to-[#0099FF] flex items-center justify-center mx-auto mb-4">
                    <span className="font-orbitron font-bold text-2xl text-white">{selectedUser.name[0]}</span>
                  </div>
                  <h4 className="font-orbitron font-semibold text-lg text-white">{selectedUser.name}</h4>
                  <p className="text-[#A0A0C0] text-sm">{selectedUser.email}</p>
                </div>
                <div className="space-y-3 mb-6">
                  <div className="flex justify-between p-3 rounded-lg bg-white/5">
                    <span className="text-[#A0A0C0]">SW Coins</span>
                    <span className="text-white font-mono">{selectedUser.swCoins}</span>
                  </div>
                  <div className="flex justify-between p-3 rounded-lg bg-white/5">
                    <span className="text-[#A0A0C0]">BP Coins</span>
                    <span className="text-white font-mono">{selectedUser.bpCoins}</span>
                  </div>
                  <div className="flex justify-between p-3 rounded-lg bg-white/5">
                    <span className="text-[#A0A0C0]">Статус</span>
                    <span className={selectedUser.status === 'active' ? 'text-green-400' : 'text-red-400'}>
                      {selectedUser.status === 'active' ? 'Активен' : 'Заблокирован'}
                    </span>
                  </div>
                </div>
                <div className="flex gap-3">
                  <NeonButton variant="primary" className="flex-1" icon={<Edit3 className="w-4 h-4" />}>
                    Редактировать
                  </NeonButton>
                  <button className="p-3 rounded-xl bg-red-500/20 text-red-400 hover:bg-red-500/30 transition-colors">
                    <Ban className="w-5 h-5" />
                  </button>
                </div>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </div>
  );
};

export default Admin;
