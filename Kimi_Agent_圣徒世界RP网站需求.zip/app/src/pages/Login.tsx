import { useState } from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { 
  User, 
  Lock, 
  Eye, 
  EyeOff, 
  Gamepad2, 
  ArrowRight,
  AlertCircle,
  Check
} from 'lucide-react';
import NeonButton from '../components/NeonButton';

const Login = () => {
  const [formData, setFormData] = useState({
    login: '',
    password: '',
    rememberMe: false
  });
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setIsLoading(true);

    // Simulate login
    setTimeout(() => {
      setIsLoading(false);
      if (formData.login && formData.password) {
        // Success - would redirect to dashboard
        console.log('Login successful');
      } else {
        setError('Введите логин и пароль');
      }
    }, 1500);
  };

  return (
    <div className="min-h-screen flex items-center justify-center pt-20 pb-10 px-4">
      {/* Background effects */}
      <div className="absolute inset-0 z-0 overflow-hidden">
        <div className="absolute top-1/4 left-1/4 w-[600px] h-[600px] bg-[#FF3399]/15 rounded-full blur-[180px]" />
        <div className="absolute bottom-1/4 right-1/4 w-[600px] h-[600px] bg-[#0099FF]/15 rounded-full blur-[180px]" />
      </div>

      <div className="relative z-10 w-full max-w-5xl">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-10 items-center">
          {/* Left side - Form */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
          >
            <div className="glass rounded-3xl p-8 sm:p-10">
              <div className="text-center mb-8">
                <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-[#FF3399] to-[#0099FF] flex items-center justify-center mx-auto mb-6 shadow-[0_0_30px_rgba(255,51,153,0.4)]">
                  <Gamepad2 className="w-8 h-8 text-white" />
                </div>
                <h1 className="font-orbitron font-bold text-2xl sm:text-3xl text-white mb-2">
                  Вход в аккаунт
                </h1>
                <p className="text-[#A0A0C0] text-sm">
                  Единый вход для сайта и игры
                </p>
              </div>

              {error && (
                <motion.div
                  initial={{ opacity: 0, y: -10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="flex items-center gap-2 p-4 rounded-xl bg-red-500/10 border border-red-500/30 text-red-400 text-sm mb-6"
                >
                  <AlertCircle className="w-4 h-4 flex-shrink-0" />
                  {error}
                </motion.div>
              )}

              <form onSubmit={handleSubmit} className="space-y-5">
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.1 }}
                >
                  <label className="block text-[#A0A0C0] text-sm mb-2">Логин</label>
                  <div className="relative">
                    <User className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-[#A0A0C0]" />
                    <input
                      type="text"
                      value={formData.login}
                      onChange={(e) => setFormData({ ...formData, login: e.target.value })}
                      placeholder="Введите ваш логин"
                      className="input-glass pl-12"
                    />
                  </div>
                </motion.div>

                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.2 }}
                >
                  <label className="block text-[#A0A0C0] text-sm mb-2">Пароль</label>
                  <div className="relative">
                    <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-[#A0A0C0]" />
                    <input
                      type={showPassword ? 'text' : 'password'}
                      value={formData.password}
                      onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                      placeholder="Введите ваш пароль"
                      className="input-glass pl-12 pr-12"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-4 top-1/2 -translate-y-1/2 text-[#A0A0C0] hover:text-white transition-colors"
                    >
                      {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                    </button>
                  </div>
                </motion.div>

                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.3 }}
                  className="flex items-center justify-between"
                >
                  <label className="flex items-center gap-2 cursor-pointer group">
                    <div className="relative">
                      <input
                        type="checkbox"
                        checked={formData.rememberMe}
                        onChange={(e) => setFormData({ ...formData, rememberMe: e.target.checked })}
                        className="sr-only"
                      />
                      <div className={`w-5 h-5 rounded border transition-all duration-300 flex items-center justify-center ${
                        formData.rememberMe 
                          ? 'bg-gradient-to-br from-[#FF3399] to-[#0099FF] border-transparent' 
                          : 'border-white/20 group-hover:border-[#FF3399]/50'
                      }`}>
                        {formData.rememberMe && <Check className="w-3 h-3 text-white" />}
                      </div>
                    </div>
                    <span className="text-[#A0A0C0] text-sm group-hover:text-white transition-colors">Запомнить меня</span>
                  </label>
                  <Link to="/forgot-password" className="text-[#FF3399] text-sm hover:underline">
                    Забыли пароль?
                  </Link>
                </motion.div>

                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.4 }}
                >
                  <NeonButton
                    type="submit"
                    variant="primary"
                    className="w-full"
                    disabled={isLoading}
                    icon={isLoading ? undefined : <ArrowRight className="w-5 h-5" />}
                  >
                    {isLoading ? (
                      <div className="flex items-center gap-2">
                        <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                        Вход...
                      </div>
                    ) : (
                      'Войти'
                    )}
                  </NeonButton>
                </motion.div>
              </form>

              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.5 }}
                className="mt-6 pt-6 border-t border-white/10 text-center"
              >
                <p className="text-[#A0A0C0] text-sm">
                  Регистрация происходит через игру.{' '}
                  <Link to="/" className="text-[#FF3399] hover:underline">
                    Как начать?
                  </Link>
                </p>
              </motion.div>
            </div>
          </motion.div>

          {/* Right side - Info */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6, delay: 0.2, ease: [0.16, 1, 0.3, 1] }}
            className="hidden lg:block"
          >
            <div className="space-y-8">
              <div>
                <h2 className="font-orbitron font-bold text-4xl text-white mb-4">
                  Добро пожаловать в <span className="gradient-text">Saints World</span>
                </h2>
                <p className="text-[#A0A0C0] text-lg leading-relaxed">
                  Погрузись в мир бесконечных возможностей Лос-Сантоса. 
                  Создай своего персонажа, выбери путь и начни свою историю.
                </p>
              </div>

              <div className="space-y-4">
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-[#FF3399]/20 to-[#FF3399]/5 flex items-center justify-center flex-shrink-0">
                    <Check className="w-6 h-6 text-[#FF3399]" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-white mb-1">Единый аккаунт</h3>
                    <p className="text-[#A0A0C0] text-sm">Один логин для сайта и игры</p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-[#0099FF]/20 to-[#0099FF]/5 flex items-center justify-center flex-shrink-0">
                    <Check className="w-6 h-6 text-[#0099FF]" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-white mb-1">Личный кабинет</h3>
                    <p className="text-[#A0A0C0] text-sm">Управляй персонажами и имуществом</p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-[#9933FF]/20 to-[#9933FF]/5 flex items-center justify-center flex-shrink-0">
                    <Check className="w-6 h-6 text-[#9933FF]" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-white mb-1">Безопасность</h3>
                    <p className="text-[#A0A0C0] text-sm">Защита аккаунта и двухфакторная аутентификация</p>
                  </div>
                </div>
              </div>

              <div className="glass rounded-2xl p-6">
                <div className="flex items-center justify-between mb-4">
                  <span className="text-[#A0A0C0] text-sm">Сейчас онлайн</span>
                  <span className="font-orbitron font-bold text-2xl text-white">215</span>
                </div>
                <div className="progress-neon">
                  <div className="progress-neon-fill" style={{ width: '21.5%' }} />
                </div>
                <div className="flex justify-between mt-2 text-xs text-[#A0A0C0]">
                  <span>0</span>
                  <span>1000 слотов</span>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
};

export default Login;
