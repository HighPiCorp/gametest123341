import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  User, 
  Car, 
  Home, 
  Settings, 
  History, 
  LogOut,
  TrendingUp,
  Gift,
  DollarSign,
  Shield,
  Edit3,
  Lock,
  Smartphone,
  Bell,
  ChevronRight,
  MapPin,
  Clock
} from 'lucide-react';
import GlassCard from '../components/GlassCard';
import NeonButton from '../components/NeonButton';

const Dashboard = () => {
  const [activeTab, setActiveTab] = useState('overview');
  const [show2FASetup, setShow2FASetup] = useState(false);

  const userData = {
    name: 'Alex_Rodriguez',
    avatar: null,
    registerDate: '15.01.2025',
    balances: {
      swCoins: 1250,
      bpCoins: 450,
      dollars: 875000
    }
  };

  const characters = [
    {
      id: 1,
      name: 'Alex_Rodriguez',
      level: 42,
      playTime: '156ч 30м',
      health: 100,
      armor: 50,
      faction: 'La Cosa Nostra',
      job: 'Лидер',
      avatar: null
    },
    {
      id: 2,
      name: 'Marcus_Stone',
      level: 28,
      playTime: '89ч 15м',
      health: 100,
      armor: 0,
      faction: 'Без фракции',
      job: 'Таксист',
      avatar: null
    }
  ];

  const vehicles = [
    { id: 1, name: 'Infernus', plate: 'SW-1337', condition: 95, type: 'Спорткар', price: 2500000 },
    { id: 2, name: 'Banshee', plate: 'SW-9999', condition: 78, type: 'Спорткар', price: 1200000 },
    { id: 3, name: 'Sanchez', plate: 'SW-7777', condition: 100, type: 'Мотоцикл', price: 150000 }
  ];

  const properties = [
    { id: 1, type: 'Дом', address: 'Vinewood Hills, 1234', price: 5000000, garage: 2 },
    { id: 2, type: 'Бизнес', address: 'Downtown, 567', price: 15000000, income: 50000 }
  ];

  const recentActivity = [
    { action: 'Пополнение баланса', amount: '+500 SW', date: '18.03.2025 14:30', type: 'positive' },
    { action: 'Покупка транспорта', amount: '-2 500 000 $', date: '17.03.2025 20:15', type: 'negative' },
    { action: 'Начисление BP Coins', amount: '+50 BP', date: '16.03.2025 09:00', type: 'positive' },
    { action: 'Продажа рыбы', amount: '+15 000 $', date: '15.03.2025 18:45', type: 'positive' }
  ];

  const sidebarItems = [
    { id: 'overview', label: 'Обзор', icon: User },
    { id: 'characters', label: 'Персонажи', icon: Shield },
    { id: 'property', label: 'Имущество', icon: Home },
    { id: 'settings', label: 'Настройки', icon: Settings },
    { id: 'history', label: 'История', icon: History },
  ];

  const renderOverview = () => (
    <div className="space-y-6">
      {/* Welcome */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="font-orbitron font-bold text-2xl text-white mb-1">
            Добро пожаловать, <span className="gradient-text">{userData.name}</span>
          </h2>
          <p className="text-[#A0A0C0] text-sm">Последний вход: сегодня в 14:30</p>
        </div>
        <NeonButton to="/donate" variant="primary" size="sm" icon={<Gift className="w-4 h-4" />}>
          Пополнить
        </NeonButton>
      </div>

      {/* Balance Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <GlassCard glow="pink" className="relative overflow-hidden">
          <div className="absolute top-0 right-0 w-24 h-24 bg-[#FF3399]/10 rounded-full blur-2xl" />
          <div className="flex items-center gap-3 mb-3">
            <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-[#FF3399] to-[#FF66B3] flex items-center justify-center">
              <Gift className="w-5 h-5 text-white" />
            </div>
            <span className="text-[#A0A0C0] text-sm">SW Coins</span>
          </div>
          <div className="font-orbitron font-bold text-2xl text-white">
            {userData.balances.swCoins.toLocaleString()}
          </div>
        </GlassCard>

        <GlassCard glow="blue" className="relative overflow-hidden">
          <div className="absolute top-0 right-0 w-24 h-24 bg-[#0099FF]/10 rounded-full blur-2xl" />
          <div className="flex items-center gap-3 mb-3">
            <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-[#0099FF] to-[#33ADFF] flex items-center justify-center">
              <TrendingUp className="w-5 h-5 text-white" />
            </div>
            <span className="text-[#A0A0C0] text-sm">BP Coins</span>
          </div>
          <div className="font-orbitron font-bold text-2xl text-white">
            {userData.balances.bpCoins.toLocaleString()}
          </div>
        </GlassCard>

        <GlassCard glow="none" className="relative overflow-hidden">
          <div className="absolute top-0 right-0 w-24 h-24 bg-[#22C55E]/10 rounded-full blur-2xl" />
          <div className="flex items-center gap-3 mb-3">
            <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-[#22C55E] to-[#4ADE80] flex items-center justify-center">
              <DollarSign className="w-5 h-5 text-white" />
            </div>
            <span className="text-[#A0A0C0] text-sm">Игровые $</span>
          </div>
          <div className="font-orbitron font-bold text-2xl text-white">
            ${userData.balances.dollars.toLocaleString()}
          </div>
        </GlassCard>
      </div>

      {/* Quick Actions */}
      <GlassCard>
        <h3 className="font-orbitron font-semibold text-lg text-white mb-4">Быстрые действия</h3>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          <button className="p-4 rounded-xl bg-white/5 hover:bg-[#FF3399]/10 border border-white/10 hover:border-[#FF3399]/30 transition-all duration-300 text-center group">
            <Gift className="w-6 h-6 text-[#FF3399] mx-auto mb-2 group-hover:scale-110 transition-transform" />
            <span className="text-white text-sm">Пополнить</span>
          </button>
          <button className="p-4 rounded-xl bg-white/5 hover:bg-[#0099FF]/10 border border-white/10 hover:border-[#0099FF]/30 transition-all duration-300 text-center group">
            <TrendingUp className="w-6 h-6 text-[#0099FF] mx-auto mb-2 group-hover:scale-110 transition-transform" />
            <span className="text-white text-sm">Перевести</span>
          </button>
          <button className="p-4 rounded-xl bg-white/5 hover:bg-[#9933FF]/10 border border-white/10 hover:border-[#9933FF]/30 transition-all duration-300 text-center group">
            <Car className="w-6 h-6 text-[#9933FF] mx-auto mb-2 group-hover:scale-110 transition-transform" />
            <span className="text-white text-sm">Магазин</span>
          </button>
          <button className="p-4 rounded-xl bg-white/5 hover:bg-[#22C55E]/10 border border-white/10 hover:border-[#22C55E]/30 transition-all duration-300 text-center group">
            <History className="w-6 h-6 text-[#22C55E] mx-auto mb-2 group-hover:scale-110 transition-transform" />
            <span className="text-white text-sm">История</span>
          </button>
        </div>
      </GlassCard>

      {/* Recent Activity */}
      <GlassCard>
        <h3 className="font-orbitron font-semibold text-lg text-white mb-4">Последняя активность</h3>
        <div className="space-y-3">
          {recentActivity.map((activity, index) => (
            <div key={index} className="flex items-center justify-between p-3 rounded-lg bg-white/5">
              <div className="flex items-center gap-3">
                <div className={`w-2 h-2 rounded-full ${activity.type === 'positive' ? 'bg-green-400' : 'bg-red-400'}`} />
                <div>
                  <p className="text-white text-sm">{activity.action}</p>
                  <p className="text-[#A0A0C0] text-xs">{activity.date}</p>
                </div>
              </div>
              <span className={`font-mono font-medium ${activity.type === 'positive' ? 'text-green-400' : 'text-red-400'}`}>
                {activity.amount}
              </span>
            </div>
          ))}
        </div>
      </GlassCard>
    </div>
  );

  const renderCharacters = () => (
    <div className="space-y-6">
      <h2 className="font-orbitron font-bold text-2xl text-white">Мои персонажи</h2>
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {characters.map((char, index) => (
          <GlassCard key={char.id} delay={index * 0.1} glow="pink">
            <div className="flex items-start gap-4">
              <div className="w-20 h-20 rounded-xl bg-gradient-to-br from-[#FF3399]/20 to-[#0099FF]/20 flex items-center justify-center flex-shrink-0">
                <User className="w-10 h-10 text-[#A0A0C0]" />
              </div>
              <div className="flex-1">
                <div className="flex items-center justify-between mb-2">
                  <h3 className="font-orbitron font-semibold text-lg text-white">{char.name}</h3>
                  <span className="badge badge-pink">Lvl {char.level}</span>
                </div>
                <div className="grid grid-cols-2 gap-2 mb-3">
                  <div className="flex items-center gap-2 text-[#A0A0C0] text-sm">
                    <Clock className="w-4 h-4" />
                    {char.playTime}
                  </div>
                  <div className="flex items-center gap-2 text-[#A0A0C0] text-sm">
                    <Shield className="w-4 h-4" />
                    {char.faction}
                  </div>
                </div>
                <div className="space-y-2">
                  <div>
                    <div className="flex justify-between text-xs text-[#A0A0C0] mb-1">
                      <span>Здоровье</span>
                      <span>{char.health}%</span>
                    </div>
                    <div className="progress-neon h-1.5">
                      <div className="progress-neon-fill bg-gradient-to-r from-green-500 to-green-400" style={{ width: `${char.health}%` }} />
                    </div>
                  </div>
                  <div>
                    <div className="flex justify-between text-xs text-[#A0A0C0] mb-1">
                      <span>Броня</span>
                      <span>{char.armor}%</span>
                    </div>
                    <div className="progress-neon h-1.5">
                      <div className="progress-neon-fill bg-gradient-to-r from-[#0099FF] to-[#33ADFF]" style={{ width: `${char.armor}%` }} />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </GlassCard>
        ))}
      </div>
    </div>
  );

  const renderProperty = () => (
    <div className="space-y-6">
      <h2 className="font-orbitron font-bold text-2xl text-white">Моё имущество</h2>
      
      {/* Vehicles */}
      <div>
        <h3 className="text-[#A0A0C0] text-sm mb-4 flex items-center gap-2">
          <Car className="w-4 h-4" />
          Транспорт ({vehicles.length})
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {vehicles.map((vehicle, index) => (
            <GlassCard key={vehicle.id} delay={index * 0.1} glow="blue">
              <div className="flex items-center gap-3 mb-3">
                <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-[#0099FF]/20 to-[#0099FF]/5 flex items-center justify-center">
                  <Car className="w-6 h-6 text-[#0099FF]" />
                </div>
                <div>
                  <h4 className="font-semibold text-white">{vehicle.name}</h4>
                  <span className="text-[#A0A0C0] text-xs">{vehicle.type}</span>
                </div>
              </div>
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="text-[#A0A0C0]">Номер</span>
                  <span className="font-mono text-white">{vehicle.plate}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-[#A0A0C0]">Состояние</span>
                  <span className="text-white">{vehicle.condition}%</span>
                </div>
                <div className="progress-neon h-1.5">
                  <div 
                    className="progress-neon-fill" 
                    style={{ width: `${vehicle.condition}%` }} 
                  />
                </div>
              </div>
            </GlassCard>
          ))}
        </div>
      </div>

      {/* Properties */}
      <div>
        <h3 className="text-[#A0A0C0] text-sm mb-4 flex items-center gap-2">
          <Home className="w-4 h-4" />
          Недвижимость ({properties.length})
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {properties.map((prop, index) => (
            <GlassCard key={prop.id} delay={index * 0.1} glow="pink">
              <div className="flex items-start gap-3">
                <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-[#FF3399]/20 to-[#FF3399]/5 flex items-center justify-center flex-shrink-0">
                  <Home className="w-6 h-6 text-[#FF3399]" />
                </div>
                <div className="flex-1">
                  <div className="flex items-center justify-between mb-1">
                    <h4 className="font-semibold text-white">{prop.type}</h4>
                    <span className="badge badge-blue">${prop.price.toLocaleString()}</span>
                  </div>
                  <div className="flex items-center gap-2 text-[#A0A0C0] text-sm mb-2">
                    <MapPin className="w-4 h-4" />
                    {prop.address}
                  </div>
                  {prop.garage && (
                    <div className="text-[#A0A0C0] text-xs">
                      Гаражных мест: {prop.garage}
                    </div>
                  )}
                  {prop.income && (
                    <div className="text-green-400 text-xs">
                      +${prop.income.toLocaleString()}/час
                    </div>
                  )}
                </div>
              </div>
            </GlassCard>
          ))}
        </div>
      </div>
    </div>
  );

  const renderSettings = () => (
    <div className="space-y-6">
      <h2 className="font-orbitron font-bold text-2xl text-white">Настройки аккаунта</h2>

      {/* Change Password */}
      <GlassCard>
        <h3 className="font-orbitron font-semibold text-lg text-white mb-4 flex items-center gap-2">
          <Lock className="w-5 h-5 text-[#FF3399]" />
          Смена пароля
        </h3>
        <div className="space-y-4">
          <div>
            <label className="block text-[#A0A0C0] text-sm mb-2">Текущий пароль</label>
            <input type="password" className="input-glass" placeholder="Введите текущий пароль" />
          </div>
          <div>
            <label className="block text-[#A0A0C0] text-sm mb-2">Новый пароль</label>
            <input type="password" className="input-glass" placeholder="Введите новый пароль" />
          </div>
          <div>
            <label className="block text-[#A0A0C0] text-sm mb-2">Подтвердите пароль</label>
            <input type="password" className="input-glass" placeholder="Повторите новый пароль" />
          </div>
          <NeonButton variant="primary" size="sm" icon={<Edit3 className="w-4 h-4" />}>
            Изменить пароль
          </NeonButton>
        </div>
      </GlassCard>

      {/* 2FA */}
      <GlassCard>
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-orbitron font-semibold text-lg text-white flex items-center gap-2">
            <Smartphone className="w-5 h-5 text-[#0099FF]" />
            Двухфакторная аутентификация
          </h3>
          <button
            onClick={() => setShow2FASetup(!show2FASetup)}
            className={`relative w-14 h-7 rounded-full transition-colors duration-300 ${show2FASetup ? 'bg-[#22C55E]' : 'bg-white/20'}`}
          >
            <div className={`absolute top-1 w-5 h-5 rounded-full bg-white transition-transform duration-300 ${show2FASetup ? 'translate-x-8' : 'translate-x-1'}`} />
          </button>
        </div>
        <p className="text-[#A0A0C0] text-sm mb-4">
          Защитите свой аккаунт с помощью приложения-аутентификатора (Google Authenticator, Authy)
        </p>
        <AnimatePresence>
          {show2FASetup && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="pt-4 border-t border-white/10"
            >
              <div className="flex items-center gap-6">
                <div className="w-32 h-32 rounded-xl bg-white flex items-center justify-center">
                  <div className="w-24 h-24 bg-[#000022] rounded-lg flex items-center justify-center">
                    <span className="text-[#A0A0C0] text-xs">QR Code</span>
                  </div>
                </div>
                <div className="flex-1">
                  <p className="text-white text-sm mb-2">Секретный ключ:</p>
                  <div className="flex items-center gap-2">
                    <code className="px-3 py-2 rounded-lg bg-white/5 font-mono text-sm text-white">
                      XJ2K-9FPL-MN4Q-R8TW
                    </code>
                    <button className="p-2 rounded-lg glass hover:border-[#FF3399]/50 transition-colors">
                      <Edit3 className="w-4 h-4 text-[#A0A0C0]" />
                    </button>
                  </div>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </GlassCard>

      {/* Notifications */}
      <GlassCard>
        <h3 className="font-orbitron font-semibold text-lg text-white mb-4 flex items-center gap-2">
          <Bell className="w-5 h-5 text-[#9933FF]" />
          Уведомления
        </h3>
        <div className="space-y-3">
          {[
            { label: 'Email-уведомления о входе', checked: true },
            { label: 'Уведомления о транзакциях', checked: true },
            { label: 'Новости и обновления', checked: false },
            { label: 'События на сервере', checked: true }
          ].map((item, index) => (
            <label key={index} className="flex items-center justify-between cursor-pointer group">
              <span className="text-white group-hover:text-[#FF3399] transition-colors">{item.label}</span>
              <div className={`relative w-12 h-6 rounded-full transition-colors duration-300 ${item.checked ? 'bg-[#22C55E]' : 'bg-white/20'}`}>
                <div className={`absolute top-1 w-4 h-4 rounded-full bg-white transition-transform duration-300 ${item.checked ? 'translate-x-7' : 'translate-x-1'}`} />
              </div>
            </label>
          ))}
        </div>
      </GlassCard>
    </div>
  );

  const renderHistory = () => (
    <div className="space-y-6">
      <h2 className="font-orbitron font-bold text-2xl text-white">История операций</h2>
      <GlassCard className="overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-white/10">
                <th className="text-left py-3 px-4 text-[#A0A0C0] text-sm font-medium">Действие</th>
                <th className="text-left py-3 px-4 text-[#A0A0C0] text-sm font-medium">Сумма</th>
                <th className="text-left py-3 px-4 text-[#A0A0C0] text-sm font-medium">Дата</th>
                <th className="text-left py-3 px-4 text-[#A0A0C0] text-sm font-medium">Статус</th>
              </tr>
            </thead>
            <tbody>
              {[
                { action: 'Пополнение SW Coins', amount: '+500 SW', date: '18.03.2025 14:30', status: 'completed' },
                { action: 'Покупка Infernus', amount: '-2 500 000 $', date: '17.03.2025 20:15', status: 'completed' },
                { action: 'Начисление BP Coins', amount: '+50 BP', date: '16.03.2025 09:00', status: 'completed' },
                { action: 'Продажа рыбы', amount: '+15 000 $', date: '15.03.2025 18:45', status: 'completed' },
                { action: 'Покупка VIP', amount: '-1000 SW', date: '14.03.2025 12:00', status: 'completed' },
                { action: 'Перевод игроку', amount: '-50 000 $', date: '13.03.2025 21:30', status: 'completed' },
              ].map((item, index) => (
                <tr key={index} className="border-b border-white/5 hover:bg-white/5 transition-colors">
                  <td className="py-3 px-4 text-white text-sm">{item.action}</td>
                  <td className={`py-3 px-4 font-mono text-sm ${item.amount.startsWith('+') ? 'text-green-400' : 'text-red-400'}`}>
                    {item.amount}
                  </td>
                  <td className="py-3 px-4 text-[#A0A0C0] text-sm">{item.date}</td>
                  <td className="py-3 px-4">
                    <span className="badge badge-blue text-xs">Выполнено</span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </GlassCard>
    </div>
  );

  return (
    <div className="min-h-screen pt-24 pb-10 px-4 sm:px-6 lg:px-12 xl:px-20">
      <div className="flex flex-col lg:flex-row gap-6">
        {/* Sidebar */}
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.5 }}
          className="lg:w-64 flex-shrink-0"
        >
          <div className="glass rounded-2xl p-4 sticky top-24">
            {/* User info */}
            <div className="flex items-center gap-3 mb-6 pb-6 border-b border-white/10">
              <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-[#FF3399] to-[#0099FF] flex items-center justify-center">
                <User className="w-6 h-6 text-white" />
              </div>
              <div>
                <p className="font-semibold text-white text-sm">{userData.name}</p>
                <p className="text-[#A0A0C0] text-xs">С {userData.registerDate}</p>
              </div>
            </div>

            {/* Navigation */}
            <nav className="space-y-1">
              {sidebarItems.map((item) => (
                <button
                  key={item.id}
                  onClick={() => setActiveTab(item.id)}
                  className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-300 ${
                    activeTab === item.id
                      ? 'bg-gradient-to-r from-[#FF3399]/20 to-[#0099FF]/20 border border-[#FF3399]/30 text-white'
                      : 'text-[#A0A0C0] hover:text-white hover:bg-white/5'
                  }`}
                >
                  <item.icon className={`w-5 h-5 ${activeTab === item.id ? 'text-[#FF3399]' : ''}`} />
                  <span className="text-sm">{item.label}</span>
                  {activeTab === item.id && <ChevronRight className="w-4 h-4 ml-auto" />}
                </button>
              ))}
            </nav>

            {/* Logout */}
            <button className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-red-400 hover:bg-red-500/10 transition-all duration-300 mt-6">
              <LogOut className="w-5 h-5" />
              <span className="text-sm">Выйти</span>
            </button>
          </div>
        </motion.div>

        {/* Main content */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.1 }}
          className="flex-1"
        >
          <AnimatePresence mode="wait">
            <motion.div
              key={activeTab}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.3 }}
            >
              {activeTab === 'overview' && renderOverview()}
              {activeTab === 'characters' && renderCharacters()}
              {activeTab === 'property' && renderProperty()}
              {activeTab === 'settings' && renderSettings()}
              {activeTab === 'history' && renderHistory()}
            </motion.div>
          </AnimatePresence>
        </motion.div>
      </div>
    </div>
  );
};

export default Dashboard;
