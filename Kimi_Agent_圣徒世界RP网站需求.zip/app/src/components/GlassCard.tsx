import { motion } from 'framer-motion';
import type { ReactNode } from 'react';

interface GlassCardProps {
  children: ReactNode;
  className?: string;
  hover?: boolean;
  glow?: 'pink' | 'blue' | 'none';
  delay?: number;
  onClick?: () => void;
}

const GlassCard = ({ 
  children, 
  className = '', 
  hover = true, 
  glow = 'none',
  delay = 0,
  onClick
}: GlassCardProps) => {
  const glowClasses = {
    pink: 'hover:shadow-[0_0_40px_rgba(255,51,153,0.3)]',
    blue: 'hover:shadow-[0_0_40px_rgba(0,153,255,0.3)]',
    none: ''
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      transition={{ 
        duration: 0.5, 
        delay,
        ease: [0.25, 0.46, 0.45, 0.94]
      }}
      viewport={{ once: true, margin: '-50px' }}
      onClick={onClick}
      className={`
        glass rounded-2xl p-6
        ${hover ? 'card-hover' : ''}
        ${glowClasses[glow]}
        ${className}
        ${onClick ? 'cursor-pointer' : ''}
      `}
    >
      {children}
    </motion.div>
  );
};

export default GlassCard;
