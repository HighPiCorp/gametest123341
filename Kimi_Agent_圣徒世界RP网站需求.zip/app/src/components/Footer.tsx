import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Gamepad2, Newspaper, ShoppingCart, MessageSquare, HelpCircle, Shield, FileText, Mail, ExternalLink } from 'lucide-react';

const Footer = () => {
  const currentYear = new Date().getFullYear();

  const footerLinks = {
    navigation: [
      { label: 'Главная', path: '/', icon: Gamepad2 },
      { label: 'Новости', path: '/news', icon: Newspaper },
      { label: 'Донат', path: '/donate', icon: ShoppingCart },
      { label: 'Форум', path: '/forum', icon: MessageSquare },
      { label: 'FAQ', path: '/faq', icon: HelpCircle },
    ],
    legal: [
      { label: 'Правила проекта', path: '/rules', icon: Shield },
      { label: 'Политика конфиденциальности', path: '/privacy', icon: FileText },
      { label: 'Соглашение', path: '/terms', icon: FileText },
    ],
    support: [
      { label: 'Техническая поддержка', path: '/support', icon: Mail },
      { label: 'Discord', path: '#', icon: ExternalLink, external: true },
      { label: 'VK', path: '#', icon: ExternalLink, external: true },
    ],
  };

  const socialLinks = [
    { name: 'Discord', icon: 'M', href: '#' },
    { name: 'VK', icon: 'VK', href: '#' },
    { name: 'Telegram', icon: 'TG', href: '#' },
    { name: 'YouTube', icon: 'YT', href: '#' },
  ];

  return (
    <footer className="relative mt-20">
      {/* Gradient top border */}
      <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-[#FF3399] to-transparent" />

      <div className="w-full px-4 sm:px-6 lg:px-12 xl:px-20 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10">
          {/* Brand Column */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            viewport={{ once: true }}
            className="lg:col-span-1"
          >
            <Link to="/" className="flex items-center gap-3 mb-6">
              <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-[#FF3399] to-[#0099FF] flex items-center justify-center">
                <span className="font-orbitron font-bold text-white text-xl">SW</span>
              </div>
              <div>
                <span className="font-orbitron font-bold text-white text-xl tracking-wide block">SAINTS</span>
                <span className="font-orbitron font-bold text-[#FF3399] text-sm tracking-wide">WORLD RP</span>
              </div>
            </Link>
            <p className="text-[#A0A0C0] text-sm leading-relaxed mb-6">
              Погрузись в мир бесконечных возможностей Лос-Сантоса. 
              Уникальный RP-опыт с реалистичной экономикой, фракциями и системой взаимодействия.
            </p>
            <div className="flex gap-3">
              {socialLinks.map((social) => (
                <a
                  key={social.name}
                  href={social.href}
                  className="w-10 h-10 rounded-lg glass flex items-center justify-center text-[#A0A0C0] hover:text-white hover:border-[#FF3399]/50 hover:shadow-[0_0_20px_rgba(255,51,153,0.3)] transition-all duration-300"
                  title={social.name}
                >
                  <span className="font-orbitron text-xs font-bold">{social.icon}</span>
                </a>
              ))}
            </div>
          </motion.div>

          {/* Navigation Column */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.1 }}
            viewport={{ once: true }}
          >
            <h3 className="font-orbitron font-semibold text-white mb-6">Навигация</h3>
            <ul className="space-y-3">
              {footerLinks.navigation.map((link) => (
                <li key={link.path}>
                  <Link
                    to={link.path}
                    className="flex items-center gap-2 text-[#A0A0C0] hover:text-white transition-colors duration-300 group"
                  >
                    <link.icon className="w-4 h-4 group-hover:text-[#FF3399] transition-colors" />
                    <span className="text-sm">{link.label}</span>
                  </Link>
                </li>
              ))}
            </ul>
          </motion.div>

          {/* Legal Column */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
            viewport={{ once: true }}
          >
            <h3 className="font-orbitron font-semibold text-white mb-6">Правовая информация</h3>
            <ul className="space-y-3">
              {footerLinks.legal.map((link) => (
                <li key={link.path}>
                  <Link
                    to={link.path}
                    className="flex items-center gap-2 text-[#A0A0C0] hover:text-white transition-colors duration-300 group"
                  >
                    <link.icon className="w-4 h-4 group-hover:text-[#FF3399] transition-colors" />
                    <span className="text-sm">{link.label}</span>
                  </Link>
                </li>
              ))}
            </ul>
          </motion.div>

          {/* Support Column */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.3 }}
            viewport={{ once: true }}
          >
            <h3 className="font-orbitron font-semibold text-white mb-6">Поддержка</h3>
            <ul className="space-y-3">
              {footerLinks.support.map((link) => (
                <li key={link.label}>
                  {link.external ? (
                    <a
                      href={link.path}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center gap-2 text-[#A0A0C0] hover:text-white transition-colors duration-300 group"
                    >
                      <link.icon className="w-4 h-4 group-hover:text-[#FF3399] transition-colors" />
                      <span className="text-sm">{link.label}</span>
                    </a>
                  ) : (
                    <Link
                      to={link.path}
                      className="flex items-center gap-2 text-[#A0A0C0] hover:text-white transition-colors duration-300 group"
                    >
                      <link.icon className="w-4 h-4 group-hover:text-[#FF3399] transition-colors" />
                      <span className="text-sm">{link.label}</span>
                    </Link>
                  )}
                </li>
              ))}
            </ul>
          </motion.div>
        </div>

        {/* Bottom Bar */}
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          transition={{ duration: 0.5, delay: 0.4 }}
          viewport={{ once: true }}
          className="mt-12 pt-8 border-t border-white/10"
        >
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <p className="text-[#A0A0C0] text-sm">
              © {currentYear} Saints World Role Play. Все права защищены.
            </p>
            <p className="text-[#A0A0C0]/60 text-xs">
              GTA 5 и Grand Theft Auto являются товарными знаками Take-Two Interactive Software, Inc.
            </p>
          </div>
        </motion.div>
      </div>
    </footer>
  );
};

export default Footer;
